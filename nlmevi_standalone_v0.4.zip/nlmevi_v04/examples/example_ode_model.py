"""Example: fit an NLME model whose predictions come from an ODE solver.

This uses a one-compartment IV-bolus model

    dA/dt = -(CL / V) * A
    C     = A / V

and integrates it with nlmevi.rk4_integrate(), a small differentiable
pure-PyTorch RK4 helper. The model is intentionally simple so the example
focuses on how an ODE model plugs into the same nlmevi() inference API.

Run from the repository root:

    python examples/example_ode_model.py

The shipped settings use a short fixed-step VI fit so the example runs
quickly. For real estimation, switch to adaptive=True and allow a larger
max_steps (for example 25000), as in the other examples.
"""

import math
import numpy as np
import pandas as pd
import torch

from nlmevi import NLMEModel, IWVI, nlmevi, rk4_integrate


TRUE = {
    "CL": 3.0,
    "V": 30.0,
    "omega_CL": 0.30,
    "omega_V": 0.20,
    "sigma": 0.20,
}

DOSE = 100.0
OBS_TIMES = np.array([0.5, 1.0, 2.0, 4.0, 8.0, 12.0])


def simulate_data(n_subjects=20, seed=123):
    """Simulate long-format IV-bolus PK data."""
    rng = np.random.default_rng(seed)
    rows = []

    for sid in range(1, n_subjects + 1):
        eta_cl = rng.normal(0.0, TRUE["omega_CL"])
        eta_v = rng.normal(0.0, TRUE["omega_V"])

        CL = TRUE["CL"] * np.exp(eta_cl)
        V = TRUE["V"] * np.exp(eta_v)
        ke = CL / V

        rows.append(dict(ID=sid, TIME=0.0, EVID=1, AMT=DOSE, CMT=1, DV=np.nan))

        for t in OBS_TIMES:
            # Exact solution is used only to generate clean synthetic truth.
            # The fitted model below predicts by numerically solving the ODE.
            pred = DOSE / V * np.exp(-ke * t)
            dv = pred * np.exp(rng.normal(0.0, TRUE["sigma"]))
            rows.append(dict(ID=sid, TIME=float(t), EVID=0, AMT=0.0, CMT=1, DV=dv))

    return pd.DataFrame(rows)


class OneCmtIVOde(NLMEModel):
    """One-compartment IV model solved numerically with differentiable RK4.

    Individual model:
        CL_i = CL_pop * exp(eta_CL,i)
        V_i  = V_pop  * exp(eta_V,i)

    Unconstrained theta:
        [log CL, log V, log omega_CL, log omega_V, log sigma]
    """

    n_eta = 2
    theta_init = [
        math.log(2.5),
        math.log(25.0),
        math.log(0.30),
        math.log(0.30),
        math.log(0.25),
    ]
    parameter_names = ["CL", "V", "omega_CL", "omega_V", "sigma"]
    omega_indices = (2, 3)

    @staticmethod
    def unpack(theta):
        tv = theta[:2]
        omega = torch.exp(theta[2:4])
        sigma = torch.exp(theta[4])
        return tv, omega, sigma

    def log_prior(self, eta, theta):
        _, omega, _ = self.unpack(theta)
        return (
            -0.5 * (eta / omega) ** 2
            - torch.log(omega)
            - 0.5 * math.log(2.0 * math.pi)
        ).sum(-1)

    def predict(self, batch, eta, theta):
        tv, _, _ = self.unpack(theta)

        CL = torch.exp(tv[0] + eta[..., 0])
        V = torch.exp(tv[1] + eta[..., 1])

        # This simple example assumes the same observation-time grid for all
        # subjects. That keeps the ODE example focused and easy to read.
        times = batch["t"][0]
        if not torch.allclose(batch["t"], times.expand_as(batch["t"])):
            raise ValueError("OneCmtIVOde example expects common observation times")

        # Initial amount comes from each subject's first IV dose event.
        dose = batch["dose_amt"][:, 0]
        while dose.ndim < CL.ndim:
            dose = dose.unsqueeze(0)

        # State shape (..., N, 1). The helper preserves all leading
        # importance-sample and subject dimensions.
        y0 = dose.unsqueeze(-1)

        def rhs(t, state):
            A = state[..., 0]
            dA = -(CL / V) * A
            return dA.unsqueeze(-1)

        traj = rk4_integrate(rhs, y0, times, dt_max=0.25)
        A = traj[..., 0]                    # (..., N, T)
        return A / V.unsqueeze(-1)

    def log_lik(self, batch, eta, theta):
        _, _, sigma = self.unpack(theta)
        pred = self.predict(batch, eta, theta).clamp_min(1e-12)
        resid = batch["logy"] - torch.log(pred)
        ll = (
            -0.5 * (resid / sigma) ** 2
            - torch.log(sigma)
            - 0.5 * math.log(2.0 * math.pi)
        )
        return (ll * batch["mask"]).sum(-1)

    def log_joint(self, batch, eta, theta):
        return self.log_prior(eta, theta) + self.log_lik(batch, eta, theta)


if __name__ == "__main__":
    data = simulate_data()
    model = OneCmtIVOde()

    print("True parameters:")
    for name, value in TRUE.items():
        print(f"  {name:10s} = {value:.3f}")

    fit = nlmevi(
        model,
        data,
        est=IWVI(
            posterior="amortized",
            family="gaussian",
            K=2,
            adaptive=False,
            n_steps=100,
            eval_k=100,
            seed=123,
        ),
        encoder_features=["TIME", "LOG_DV", "DV_MASK", "EVID", "AMT", "CMT"],
    )

    print("\nFit:")
    print(fit)
    print("\nEstimate table:")
    out = fit.summary().copy()
    out["truth"] = out["parameter"].map(TRUE)
    print(out.to_string(index=False))

    print(
        "\nNOTE: this example uses only 100 fixed optimization steps so it runs "
        "quickly. The point is to demonstrate the ODE interface, not convergence. "
        "For an actual fit, use adaptive=True and a larger max_steps."
    )
