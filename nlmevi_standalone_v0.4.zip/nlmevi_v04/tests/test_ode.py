import numpy as np
import torch

from nlmevi import rk4_integrate


def test_rk4_matches_exponential_decay_and_has_gradient():
    k = torch.tensor(0.2, requires_grad=True)
    y0 = torch.tensor([[10.0]])
    times = torch.tensor([0.5, 1.0, 2.0, 4.0])

    def rhs(t, y):
        return -k * y

    out = rk4_integrate(rhs, y0, times, dt_max=0.05)[0, :, 0]
    exact = 10.0 * torch.exp(-k.detach() * times)
    assert torch.allclose(out.detach(), exact, atol=1e-6, rtol=1e-5)

    out[-1].backward()
    assert k.grad is not None
    assert np.isfinite(float(k.grad))
