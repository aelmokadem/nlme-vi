"""Small differentiable ODE helpers for NLME models.

The functions here are deliberately minimal and implemented only with
PyTorch operations so gradients flow through the numerical solution into
population parameters and random effects.
"""
from __future__ import annotations

import torch


def rk4_integrate(rhs, y0: torch.Tensor, times: torch.Tensor, *, dt_max: float = 0.05) -> torch.Tensor:
    """Integrate an ODE with fixed-step classical RK4 at requested times.

    Parameters
    ----------
    rhs:
        Callable ``rhs(t, y) -> dy/dt`` using PyTorch operations.
    y0:
        Initial state with shape ``(..., n_state)``.
    times:
        One-dimensional tensor of nondecreasing output times. The first time
        must be >= 0. Integration starts at t=0 and returns the state at every
        requested time.
    dt_max:
        Maximum internal RK4 step size.

    Returns
    -------
    torch.Tensor
        Shape ``(..., n_times, n_state)``.

    Notes
    -----
    This helper intentionally targets the common educational/research case in
    which all subjects share the same requested output times. Subject-specific
    dosing/event changes can still be handled inside a custom model, but a full
    NONMEM-style event solver is outside this minimal package.
    """
    if times.ndim != 1:
        raise ValueError("times must be a 1D tensor")
    if times.numel() == 0:
        raise ValueError("times must contain at least one value")
    if torch.any(times < 0):
        raise ValueError("times must be nonnegative")
    if torch.any(times[1:] < times[:-1]):
        raise ValueError("times must be nondecreasing")
    if dt_max <= 0:
        raise ValueError("dt_max must be > 0")

    y = y0
    t_cur = torch.zeros((), dtype=times.dtype, device=times.device)
    outs = []

    for target in times:
        # Number of substeps is chosen from detached scalar timing metadata;
        # the state/parameter calculations themselves remain differentiable.
        interval = float((target - t_cur).detach().cpu())
        n_steps = max(1, int(torch.ceil(torch.tensor(interval / dt_max)).item())) if interval > 0 else 0
        if n_steps:
            h = (target - t_cur) / n_steps
            for _ in range(n_steps):
                k1 = rhs(t_cur, y)
                k2 = rhs(t_cur + h / 2, y + h * k1 / 2)
                k3 = rhs(t_cur + h / 2, y + h * k2 / 2)
                k4 = rhs(t_cur + h, y + h * k3)
                y = y + h * (k1 + 2*k2 + 2*k3 + k4) / 6
                t_cur = t_cur + h
        outs.append(y)

    return torch.stack(outs, dim=-2)
