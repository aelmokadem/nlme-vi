"""Minimal example showing how to plug in a completely different NLME model.

This is a toy exponential-decay model, not a PK recommendation. The point is
that the IWVI engine does not need to change when the structural model changes.
"""
import math
import numpy as np
import pandas as pd
import torch
from nlmevi import NLMEModel, IWVI, nlmevi


class ExponentialDecayModel(NLMEModel):
    # theta = log A, log k, log omega_k, log sigma
    n_eta = 1
    theta_init = [math.log(10.0), math.log(0.2), math.log(0.3), math.log(0.2)]
    parameter_names = ["A", "k", "omega_k", "sigma"]
    omega_indices = (2,)

    def log_joint(self, batch, eta, theta):
        A = torch.exp(theta[0])
        k = torch.exp(theta[1] + eta[..., 0:1])
        omega = torch.exp(theta[2])
        sigma = torch.exp(theta[3])
        log_prior = (-0.5*(eta[..., 0]/omega)**2 - torch.log(omega)
                     - 0.5*math.log(2*math.pi))
        pred = (A * torch.exp(-k * batch["t"])).clamp_min(1e-12)
        resid = batch["logy"] - torch.log(pred)
        ll = (-0.5*(resid/sigma)**2 - torch.log(sigma)
              - 0.5*math.log(2*math.pi))
        return log_prior + (ll * batch["mask"]).sum(-1)


rng = np.random.default_rng(5)
rows = []
for sid in range(1, 31):
    eta = rng.normal(0, 0.3)
    for t in [0.5, 1, 2, 4, 8]:
        pred = 10 * np.exp(-(0.2*np.exp(eta))*t)
        dv = pred * np.exp(rng.normal(0, 0.2))
        rows.append(dict(ID=sid, TIME=t, DV=dv, EVID=0, AMT=0))
data = pd.DataFrame(rows)

fit = nlmevi(
    ExponentialDecayModel(),
    data,
    est=IWVI(posterior="free", family="gaussian", K=8, max_steps=4000, eval_k=1000),
)
print(fit)
print(fit.summary().to_string(index=False))
