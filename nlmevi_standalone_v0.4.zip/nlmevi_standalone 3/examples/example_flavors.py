"""Run the same dataset with several IWVI flavors."""
from example_basic import simulate_dataset
from nlmevi import OneCmtOralEvents, IWVI, nlmevi


data = simulate_dataset(n=20, seed=2)
model = OneCmtOralEvents()

configs = [
    ("free Gaussian ELBO", IWVI(posterior="free", family="gaussian", K=1, max_steps=3000, eval_k=500)),
    ("amortized Gaussian IW-ELBO", IWVI(posterior="amortized", family="gaussian", K=8, max_steps=3000, eval_k=500)),
    ("amortized flow IW-ELBO", IWVI(posterior="amortized", family="flow", K=8, max_steps=3000, eval_k=500)),
    ("amortized fixed-base flow", IWVI(posterior="amortized", family="flow_fixedbase", K=8, max_steps=3000, eval_k=500)),
]

for label, est in configs:
    print("\n===", label, "===")
    fit = nlmevi(model, data, est=est)
    print(fit)
