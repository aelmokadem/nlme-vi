"""
Example: simple covariate model with weight on clearance
========================================================

This example illustrates two distinct uses of a covariate:

1. Structural covariate model:
       CL_i = CL_pop * (WT_i / 70)^beta_WT_CL * exp(eta_CL,i)

2. Amortized encoder input:
       q(eta_i | observations, times, dosing history, WT_i)

The structural model defines HOW WT affects CL.
Giving WT to the amortized encoder only helps approximate each subject's
random-effect posterior.

Run from the repository root:

    python examples/example_covariate_model.py
"""

import math

import numpy as np
import pandas as pd
import torch

from nlmevi import NLMEModel, IWVI, nlmevi


# ---------------------------------------------------------------------
# True simulation parameters
# ---------------------------------------------------------------------

TRUE = {
    "CL": 3.0,           # L/h at WT = 70 kg
    "V": 30.0,           # L
    "ka": 1.2,           # 1/h
    "beta_WT_CL": 0.75,  # weight exponent on CL
    "omega_CL": 0.30,
    "omega_V": 0.20,
    "omega_ka": 0.40,
    "sigma": 0.20,       # residual SD on log concentration
}

DOSE = 100.0
OBS_TIMES = [0.5, 1.0, 2.0, 4.0, 8.0, 24.0]


def conc_analytic(t, CL, V, ka, dose):
    """One-compartment oral PK analytic solution."""
    ke = CL / V
    denom = ka - ke
    if abs(denom) < 1e-8:
        denom = 1e-8

    return (
        dose * ka
        / (V * denom)
        * (np.exp(-ke * t) - np.exp(-ka * t))
    )


def simulate_data(n_subjects=60, seed=123):
    """Simulate long-format PK data with WT affecting clearance."""
    rng = np.random.default_rng(seed)
    rows = []

    for sid in range(1, n_subjects + 1):

        # Baseline body weight
        wt = float(np.clip(rng.normal(75.0, 12.0), 45.0, 120.0))

        # Random effects
        eta_cl = rng.normal(0.0, TRUE["omega_CL"])
        eta_v = rng.normal(0.0, TRUE["omega_V"])
        eta_ka = rng.normal(0.0, TRUE["omega_ka"])

        # Individual parameters
        CL = (
            TRUE["CL"]
            * (wt / 70.0) ** TRUE["beta_WT_CL"]
            * np.exp(eta_cl)
        )
        V = TRUE["V"] * np.exp(eta_v)
        ka = TRUE["ka"] * np.exp(eta_ka)

        # Oral dose event
        rows.append(
            dict(
                ID=sid,
                TIME=0.0,
                EVID=1,
                AMT=DOSE,
                CMT=1,
                DV=np.nan,
                WT=wt,
            )
        )

        # PK observations
        for t in OBS_TIMES:
            pred = conc_analytic(t, CL, V, ka, DOSE)
            dv = pred * np.exp(rng.normal(0.0, TRUE["sigma"]))

            rows.append(
                dict(
                    ID=sid,
                    TIME=t,
                    EVID=0,
                    AMT=0.0,
                    CMT=2,
                    DV=dv,
                    WT=wt,
                )
            )

    return pd.DataFrame(rows)


# ---------------------------------------------------------------------
# Covariate model
# ---------------------------------------------------------------------

class OneCmtOralWeightCL(NLMEModel):
    """
    1-cmt oral PK with WT on CL.

        CL_i = CL_pop * (WT_i / 70)^beta_WT_CL * exp(eta_CL,i)
        V_i  = V_pop * exp(eta_V,i)
        ka_i = ka_pop * exp(eta_ka,i)

    Unconstrained theta:
        0  log(CL_pop)
        1  log(V_pop)
        2  log(ka_pop)
        3  beta_WT_CL
        4  log(omega_CL)
        5  log(omega_V)
        6  log(omega_ka)
        7  log(sigma)
    """

    n_eta = 3

    theta_init = [
        math.log(2.5),
        math.log(25.0),
        math.log(1.0),
        0.50,
        math.log(0.30),
        math.log(0.30),
        math.log(0.30),
        math.log(0.25),
    ]

    parameter_names = [
        "CL",
        "V",
        "ka",
        "beta_WT_CL",
        "omega_CL",
        "omega_V",
        "omega_ka",
        "sigma",
    ]

    # Adaptive convergence watches these theta locations.
    omega_indices = (4, 5, 6)

    @staticmethod
    def unpack(theta):
        tv = theta[:3]
        beta_wt_cl = theta[3]
        omega = torch.exp(theta[4:7])
        sigma = torch.exp(theta[7])
        return tv, beta_wt_cl, omega, sigma

    def transform_theta(self, theta_np):
        """
        Convert optimizer-scale theta to reported parameter values.
        beta_WT_CL is unconstrained and therefore is NOT exponentiated.
        """
        theta_np = np.asarray(theta_np, dtype=float)

        return np.array([
            np.exp(theta_np[0]),
            np.exp(theta_np[1]),
            np.exp(theta_np[2]),
            theta_np[3],
            np.exp(theta_np[4]),
            np.exp(theta_np[5]),
            np.exp(theta_np[6]),
            np.exp(theta_np[7]),
        ])

    def log_prior(self, eta, theta):
        _, _, omega, _ = self.unpack(theta)

        return (
            -0.5 * (eta / omega) ** 2
            - torch.log(omega)
            - 0.5 * math.log(2.0 * math.pi)
        ).sum(-1)

    def predict(self, batch, eta, theta):
        tv, beta_wt_cl, _, _ = self.unpack(theta)

        # prepare_data(..., covariates=["WT"]) creates shape (N, 1).
        wt = batch["covariates"][:, 0]

        CL = (
            torch.exp(tv[0])
            * (wt / 70.0) ** beta_wt_cl
            * torch.exp(eta[..., 0])
        )
        V = torch.exp(tv[1] + eta[..., 1])
        ka = torch.exp(tv[2] + eta[..., 2])
        ke = CL / V

        # Add final singleton dimension for observation-time broadcasting:
        # (..., N) -> (..., N, 1)
        CL = CL.unsqueeze(-1)
        V = V.unsqueeze(-1)
        ka = ka.unsqueeze(-1)
        ke = ke.unsqueeze(-1)

        t = batch["t"]

        # eta may have leading K, so broadcast t accordingly.
        while t.ndim < eta.ndim:
            t = t.unsqueeze(0)

        denom = ka - ke
        denom = torch.where(
            denom.abs() < 1e-8,
            torch.full_like(denom, 1e-8),
            denom,
        )

        return (
            DOSE * ka
            / (V * denom)
            * (torch.exp(-ke * t) - torch.exp(-ka * t))
        )

    def log_lik(self, batch, eta, theta):
        _, _, _, sigma = self.unpack(theta)

        pred = self.predict(batch, eta, theta).clamp_min(1e-12)
        resid = batch["logy"] - torch.log(pred)

        ll = (
            -0.5 * (resid / sigma) ** 2
            - torch.log(sigma)
            - 0.5 * math.log(2.0 * math.pi)
        )

        return (ll * batch["mask"]).sum(-1)

    def log_joint(self, batch, eta, theta):
        return self.log_prior(eta, theta) + self.log_lik(batch, eta, theta)


# ---------------------------------------------------------------------
# Fit
# ---------------------------------------------------------------------

if __name__ == "__main__":

    data = simulate_data(n_subjects=60, seed=123)

    print("Data:")
    print(data.head(8))
    print()

    print("True parameters:")
    for name, value in TRUE.items():
        print(f"  {name:12s} = {value:.3f}")
    print()

    model = OneCmtOralWeightCL()

    fit = nlmevi(
        model,
        data,
        est=IWVI(
            posterior="amortized",
            family="gaussian",
            K=8,
            adaptive=True,
            max_steps=25000,
            eval_k=4000,
            seed=123,
        ),

        # WT is retained as a raw subject-level covariate for the model.
        covariates=["WT"],

        # WT can ALSO be supplied to the amortized encoder.
        # Its encoder copy is automatically standardized by nlmevi.
        encoder_features=[
            "TIME",
            "LOG_DV",
            "DV_MASK",
            "EVID",
            "AMT",
            "CMT",
            "WT",
        ],
    )

    print("Fit:")
    print(fit)
    print()

    result = fit.summary().copy()
    truth = TRUE
    result["truth"] = result["parameter"].map(truth)

    print("Estimate vs truth:")
    print(result.to_string(index=False))
    print()

    print(f"Converged: {fit.converged}")
    print(f"Steps:     {fit.n_steps}")
    print(f"LogLik:    {fit.loglik:.2f}")
    print()

    print("WT encoder scaler:")
    print(fit.encoder_scaler.get("WT"))
    print()

    print(
        "Interpretation:\n"
        "  Structural role:\n"
        "    CL_i = CL_pop * (WT_i / 70)^beta_WT_CL * exp(eta_CL,i)\n\n"
        "  Encoder role:\n"
        "    WT is also available to q(eta_i | subject data), after automatic\n"
        "    encoder standardization.\n\n"
        "  Only the structural equation defines the population covariate effect."
    )
