"""Basic end-to-end example: repeated oral doses, irregular observations."""
import numpy as np
import pandas as pd
from nlmevi import OneCmtOralEvents, IWVI, nlmevi


def simulate_dataset(n=30, seed=1):
    rng = np.random.default_rng(seed)
    rows = []
    times = np.array([1.0, 2.0, 4.0, 8.0, 13.0, 16.0, 24.0])
    doses = [(0.0, 100.0), (12.0, 100.0)]
    for sid in range(1, n+1):
        eta = rng.normal(size=3) * np.array([0.30, 0.20, 0.40])
        CL, V, ka = np.array([3.0, 30.0, 1.2]) * np.exp(eta)
        ke = CL / V
        for td, amt in doses:
            rows.append(dict(ID=sid, TIME=td, EVID=1, AMT=amt, CMT=1, DV=np.nan))
        for t in times:
            c = 0.0
            for td, amt in doses:
                if t >= td:
                    dt = t - td
                    c += (amt*ka)/(V*(ka-ke)) * (np.exp(-ke*dt)-np.exp(-ka*dt))
            dv = c * np.exp(rng.normal(0, 0.20))
            rows.append(dict(ID=sid, TIME=t, EVID=0, AMT=0.0, CMT=2, DV=dv))
    return pd.DataFrame(rows)


if __name__ == "__main__":
    data = simulate_dataset()
    model = OneCmtOralEvents()

    fit = nlmevi(
        model,
        data,
        est=IWVI(
            posterior="amortized",
            family="gaussian",
            K=8,
            max_steps=5000,
            eval_k=1000,
            seed=123,
        ),
    )

    print(fit)
    print("\nParameter table:")
    print(fit.summary().to_string(index=False))
    print("\nOmega estimates:", fit.omega)
