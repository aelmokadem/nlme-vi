"""Amortized VI with a user-configurable clinical-event encoder.

The likelihood model is the same repeated-dose 1-cmt oral PK model, but the
amortized posterior is explicitly given observation, dose, and subject-level
features.  Any numeric dataframe column can be included in encoder_features.
"""
import numpy as np
import pandas as pd
from nlmevi import OneCmtOralEvents, IWVI, nlmevi, prepare_data


TRUE = {
    "CL": 3.0, "V": 30.0, "ka": 1.2,
    "omega_CL": 0.30, "omega_V": 0.20, "omega_ka": 0.40,
    "sigma": 0.20,
}


def simulate_dataset(n=20, seed=7):
    rng = np.random.default_rng(seed)
    rows = []
    obs_times = np.array([1.0, 2.0, 4.0, 8.0, 13.0, 16.0, 24.0])

    for sid in range(1, n + 1):
        # Arbitrary subject feature to demonstrate the generic encoder API.
        wt = rng.normal(75.0, 12.0)

        # Subject-specific regimen: either 50 or 100 mg, with a second dose
        # for half the subjects. The structural model sees this through the
        # event arrays; the amortized encoder now sees it too.
        dose = 50.0 if sid % 3 == 0 else 100.0
        doses = [(0.0, dose)]
        if sid % 2 == 0:
            doses.append((12.0, dose))

        eta = rng.normal(size=3) * np.array([
            TRUE["omega_CL"], TRUE["omega_V"], TRUE["omega_ka"]
        ])
        CL, V, ka = np.array([TRUE["CL"], TRUE["V"], TRUE["ka"]]) * np.exp(eta)
        ke = CL / V

        for td, amt in doses:
            rows.append(dict(
                ID=sid, TIME=td, EVID=1, AMT=amt, CMT=1,
                DV=np.nan, WT=wt,
            ))

        for t in obs_times:
            c = 0.0
            for td, amt in doses:
                if t >= td:
                    dt = t - td
                    c += (amt * ka) / (V * (ka - ke)) * (
                        np.exp(-ke * dt) - np.exp(-ka * dt)
                    )
            if c <= 0:
                continue
            dv = c * np.exp(rng.normal(0.0, TRUE["sigma"]))
            rows.append(dict(
                ID=sid, TIME=t, EVID=0, AMT=0.0, CMT=2,
                DV=dv, WT=wt,
            ))

    return pd.DataFrame(rows)


if __name__ == "__main__":
    data = simulate_dataset()

    # These are inputs to q_phi(eta_i | subject features).  WT is not special:
    # it is simply another numeric column from the dataframe.
    features = ["TIME", "LOG_DV", "DV_MASK", "EVID", "AMT", "CMT", "WT"]

    prepared = prepare_data(data, encoder_features=features)
    print("Encoder features:", prepared.encoder_feature_names)
    print("Encoder tensor shape (subjects, events, features):", prepared.encoder_x.shape)
    print("Automatic encoder scaling:")
    for name, info in prepared.encoder_scaler.items():
        print(f"  {name:8s}: {info}")

    fit = nlmevi(
        OneCmtOralEvents(),
        prepared,
        est=IWVI(
            posterior="amortized",
            family="gaussian",
            K=8,
            adaptive=False,    # quick runnable demo only
            n_steps=500,
            eval_k=200,
            seed=123,
        ),
    )

    print("\nNOTE: this example uses only 500 fixed steps for speed; estimates are\n"
          "a smoke test, not a convergence-quality fit. For real work use\n"
          "adaptive=True with max_steps around 25000.\n")
    print("Fit:")
    print(fit)
    print("\nEstimates vs truth:")
    tab = fit.summary()
    tab["truth"] = tab["parameter"].map(TRUE)
    print(tab.to_string(index=False))
