import numpy as np
import pandas as pd
from nlmevi import prepare_data, OneCmtOralEvents, IWVI, nlmevi


def tiny_data():
    rows = []
    for sid in [1, 2, 3]:
        rows.append(dict(ID=sid, TIME=0.0, EVID=1, AMT=100.0, CMT=1, DV=np.nan))
        for t, dv in [(1.0, 2.0), (4.0, 1.5), (8.0, 0.9)]:
            rows.append(dict(ID=sid, TIME=t, EVID=0, AMT=0.0, CMT=2, DV=dv*(1+0.03*sid)))
    return pd.DataFrame(rows)


def test_prepare_data_shapes():
    d = prepare_data(tiny_data())
    assert d.logy.shape == (3, 3)
    assert d.dose_amt.shape == (3, 1)
    assert np.all(d.mask == 1)


def test_fit_smoke():
    fit = nlmevi(
        OneCmtOralEvents(), tiny_data(),
        est=IWVI(posterior="free", family="gaussian", K=1,
                 adaptive=False, n_steps=20, eval_k=20, seed=1),
    )
    assert len(fit.params) == 7
    assert np.isfinite(fit.loglik)


def test_amortized_arbitrary_encoder_feature():
    dframe = tiny_data()
    dframe["WT"] = dframe["ID"].map({1: 60.0, 2: 75.0, 3: 90.0})
    d = prepare_data(
        dframe,
        encoder_features=["TIME", "LOG_DV", "DV_MASK", "EVID", "AMT", "WT"],
    )
    assert d.encoder_x.shape[0] == 3
    assert d.encoder_x.shape[2] == 6
    assert d.encoder_feature_names[-1] == "WT"

    fit = nlmevi(
        OneCmtOralEvents(), d,
        est=IWVI(posterior="amortized", family="gaussian", K=1,
                 adaptive=False, n_steps=20, eval_k=20, seed=2),
    )
    assert len(fit.params) == 7
    assert np.isfinite(fit.loglik)


def test_encoder_scaling_default_and_optional():
    dframe = tiny_data()
    dframe["WT"] = dframe["ID"].map({1: 60.0, 2: 75.0, 3: 90.0})
    dframe["SEX"] = dframe["ID"].map({1: 0.0, 2: 1.0, 3: 1.0})
    feats = ["TIME", "LOG_DV", "DV_MASK", "EVID", "AMT", "CMT", "WT", "SEX"]

    d = prepare_data(dframe, encoder_features=feats)
    valid = d.encoder_mask.astype(bool)
    wt_j = d.encoder_feature_names.index("WT")
    time_j = d.encoder_feature_names.index("TIME")
    sex_j = d.encoder_feature_names.index("SEX")
    evid_j = d.encoder_feature_names.index("EVID")

    assert abs(d.encoder_x[..., wt_j][valid].mean()) < 1e-12
    assert abs(d.encoder_x[..., time_j][valid].mean()) < 1e-12
    assert set(np.unique(d.encoder_x[..., sex_j][valid])).issubset({0.0, 1.0})
    assert set(np.unique(d.encoder_x[..., evid_j][valid])).issubset({0.0, 1.0})
    assert d.encoder_scaler["WT"]["scaled"] is True
    assert d.encoder_scaler["SEX"]["scaled"] is False

    raw = prepare_data(dframe, encoder_features=feats, scale_encoder_features=False)
    assert np.isclose(raw.encoder_x[..., wt_j][raw.encoder_mask.astype(bool)].max(), 90.0)
    assert raw.encoder_scaler["WT"]["scaled"] is False


def test_fit_retains_encoder_scaler():
    dframe = tiny_data()
    dframe["WT"] = dframe["ID"].map({1: 60.0, 2: 75.0, 3: 90.0})
    fit = nlmevi(
        OneCmtOralEvents(), dframe,
        est=IWVI(posterior="amortized", family="gaussian", K=1,
                 adaptive=False, n_steps=5, eval_k=10, seed=3),
        encoder_features=["TIME", "LOG_DV", "DV_MASK", "EVID", "AMT", "WT"],
    )
    assert fit.encoder_scaler["WT"]["scaled"] is True
    assert "WT" in fit.encoder_feature_names
