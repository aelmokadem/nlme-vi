"""Model interface and a reusable repeated-dose one-compartment oral PK example."""
from __future__ import annotations
import math
import numpy as np
import torch


class NLMEModel:
    """Minimal contract required by the inference engine.

    Subclasses provide:
      n_eta, theta_init, parameter_names, omega_indices, log_joint(batch, eta, theta)
    """
    n_eta: int
    theta_init: list[float]
    parameter_names: list[str]
    omega_indices: tuple[int, ...]

    def transform_theta(self, theta_np):
        """Default reporting transform: exponentiate every theta element."""
        return np.exp(theta_np)

    def log_joint(self, batch, eta, theta):
        raise NotImplementedError


class OneCmtOralEvents(NLMEModel):
    """1-cmt oral PK with first-order absorption and repeated subject-specific doses.

    Parameters on log scale:
      CL, V, ka, omega_CL, omega_V, omega_ka, sigma

    Dose contributions are superposed analytically, so this supports irregular
    sampling and repeated oral doses without an ODE/event solver.
    """
    n_eta = 3
    theta_init = [math.log(2.0), math.log(20.0), math.log(0.8),
                  math.log(0.3), math.log(0.3), math.log(0.3), math.log(0.3)]
    parameter_names = ["CL", "V", "ka", "omega_CL", "omega_V", "omega_ka", "sigma"]
    omega_indices = (3, 4, 5)

    @staticmethod
    def unpack(theta):
        tv = theta[:3]
        om = torch.exp(theta[3:6])
        sigma = torch.exp(theta[6])
        return tv, om, sigma

    def log_prior(self, eta, theta):
        _, om, _ = self.unpack(theta)
        return (-0.5*(eta/om)**2 - torch.log(om) - 0.5*math.log(2*math.pi)).sum(-1)

    def predict(self, batch, eta, theta):
        tv, _, _ = self.unpack(theta)
        CL = torch.exp(tv[0] + eta[..., 0:1])
        V = torch.exp(tv[1] + eta[..., 1:2])
        ka = torch.exp(tv[2] + eta[..., 2:3])
        ke = CL / V

        # Shapes: obs times (N,T), doses (N,D), eta may have leading K.
        t_obs = batch["t"]
        dt = t_obs.unsqueeze(-1) - batch["dose_time"].unsqueeze(-2)  # N,T,D
        active = (dt >= 0).to(t_obs.dtype) * batch["dose_mask"].unsqueeze(-2)
        dt = dt.clamp_min(0.0)
        amt = batch["dose_amt"].unsqueeze(-2)

        # Add K/broadcast dimensions before N,T,D as needed.
        while dt.ndim < CL.ndim + 2:
            dt = dt.unsqueeze(0); active = active.unsqueeze(0); amt = amt.unsqueeze(0)

        denom = ka - ke
        denom = torch.where(denom.abs() < 1e-8, torch.full_like(denom, 1e-8), denom)
        # CL/V/ka (...,N,1) -> (...,N,1,1)
        CL4, V4, ka4, ke4, den4 = [x.unsqueeze(-1) for x in (CL, V, ka, ke, denom)]
        contrib = (amt * ka4) / (V4 * den4) * (torch.exp(-ke4*dt) - torch.exp(-ka4*dt))
        return (contrib * active).sum(-1)

    def log_lik(self, batch, eta, theta):
        _, _, sigma = self.unpack(theta)
        pred = self.predict(batch, eta, theta).clamp_min(1e-12)
        resid = batch["logy"] - torch.log(pred)
        ll = -0.5*(resid/sigma)**2 - torch.log(sigma) - 0.5*math.log(2*math.pi)
        return (ll * batch["mask"]).sum(-1)

    def log_joint(self, batch, eta, theta):
        return self.log_prior(eta, theta) + self.log_lik(batch, eta, theta)
