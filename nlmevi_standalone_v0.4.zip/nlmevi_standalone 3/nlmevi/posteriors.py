"""Variational posterior families used by IWVI."""
from __future__ import annotations
import math
import torch
import torch.nn as nn


class FreePosterior(nn.Module):
    amortized = False
    def __init__(self, n_subj: int, n_eta: int):
        super().__init__()
        self.mu = nn.Parameter(torch.zeros(n_subj, n_eta))
        self.log_s = nn.Parameter(torch.full((n_subj, n_eta), -1.0))

    def params(self, batch):
        return self.mu, self.log_s

    def rsample_and_logq(self, batch, K: int, drep: bool = False):
        mu, log_s = self.params(batch)
        s = torch.exp(log_s)
        eps = torch.randn((K,) + mu.shape, device=mu.device, dtype=mu.dtype)
        eta = mu + s * eps
        if drep:
            mu_d, s_d = mu.detach(), s.detach()
            z = (eta - mu_d) / s_d
            log_q = (-0.5*z**2 - torch.log(s_d) - 0.5*math.log(2*math.pi)).sum(-1)
        else:
            log_q = (-0.5*eps**2 - torch.log(s) - 0.5*math.log(2*math.pi)).sum(-1)
        return eta, log_q


class AmortizedPosterior(nn.Module):
    """Shared encoder over a configurable padded event-feature sequence.

    `batch["encoder_x"]` has shape (N, E, F), where E is the maximum number
    of clinical event rows and F is any user-selected set of numeric features.
    The event mask is concatenated explicitly so padded rows are identifiable.
    This keeps the inference engine agnostic to whether the features represent
    PK observations, doses, covariates, biomarkers, or other design variables.
    """
    amortized = True

    def __init__(self, input_dim: int, n_eta: int, hidden: int = 32):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(input_dim, hidden), nn.Tanh(),
            nn.Linear(hidden, hidden), nn.Tanh(),
            nn.Linear(hidden, 2*n_eta),
        )
        self.n_eta = n_eta

    def params(self, batch):
        if "encoder_x" not in batch or "encoder_mask" not in batch:
            raise ValueError(
                "AmortizedPosterior requires encoder_x/encoder_mask. "
                "Build data with prepare_data() or provide them in NLMEData."
            )
        mask = batch["encoder_mask"]
        x = batch["encoder_x"] * mask.unsqueeze(-1)
        x = torch.cat([x.reshape(x.shape[0], -1), mask], dim=-1)
        out = self.net(x)
        mu, log_s = out[..., :self.n_eta], out[..., self.n_eta:]
        return mu, log_s.clamp(-5.0, 2.0)

    rsample_and_logq = FreePosterior.rsample_and_logq


class AffineCoupling(nn.Module):
    def __init__(self, dim, cond_dim, hidden=16, mask_first_half=True):
        super().__init__()
        self.d1 = dim // 2 if dim > 1 else 1
        self.d2 = dim - self.d1
        self.mask_first_half = mask_first_half
        in_dim = (self.d1 if mask_first_half else self.d2) + cond_dim
        out_dim = 2 * (self.d2 if mask_first_half else self.d1)
        self.net = nn.Sequential(nn.Linear(in_dim, hidden), nn.Tanh(), nn.Linear(hidden, out_dim))
        nn.init.zeros_(self.net[-1].weight)
        nn.init.zeros_(self.net[-1].bias)

    def forward(self, z, cond, strength=1.0):
        z1, z2 = z[..., :self.d1], z[..., self.d1:]
        if self.mask_first_half:
            log_s, shift = self.net(torch.cat([z1, cond], -1)).chunk(2, -1)
            log_s = strength * 0.5 * torch.tanh(log_s)
            shift = strength * shift
            z2 = z2 * torch.exp(log_s) + shift
            return torch.cat([z1, z2], -1), log_s.sum(-1)
        log_s, shift = self.net(torch.cat([z2, cond], -1)).chunk(2, -1)
        log_s = strength * 0.5 * torch.tanh(log_s)
        shift = strength * shift
        z1 = z1 * torch.exp(log_s) + shift
        return torch.cat([z1, z2], -1), log_s.sum(-1)


class ConditionalFlow(nn.Module):
    def __init__(self, dim, cond_dim, n_layers=2, hidden=16):
        super().__init__()
        self.layers = nn.ModuleList([
            AffineCoupling(dim, cond_dim, hidden, i % 2 == 0) for i in range(n_layers)
        ])
    def forward(self, z, cond, strength=1.0):
        ld = torch.zeros(z.shape[:-1], device=z.device, dtype=z.dtype)
        for layer in self.layers:
            z, inc = layer(z, cond, strength)
            ld = ld + inc
        return z, ld


class FlowPosterior(nn.Module):
    fixed_base = False
    def __init__(self, base, n_eta):
        super().__init__()
        self.base = base
        self.amortized = base.amortized
        self.flow = ConditionalFlow(n_eta, 2*n_eta)
        self.strength = 1.0
    def rsample_and_logq(self, batch, K, drep=False):
        mu, log_s = self.base.params(batch)
        s = torch.exp(log_s)
        eps = torch.randn((K,) + mu.shape, device=mu.device, dtype=mu.dtype)
        z0 = mu + s*eps
        if drep:
            z = (z0 - mu.detach()) / s.detach()
            log_q0 = (-0.5*z**2 - torch.log(s.detach()) - 0.5*math.log(2*math.pi)).sum(-1)
        else:
            log_q0 = (-0.5*eps**2 - torch.log(s) - 0.5*math.log(2*math.pi)).sum(-1)
        cond = torch.cat([mu.detach(), log_s.detach()], -1).unsqueeze(0).expand(K, -1, -1)
        eta, logdet = self.flow(z0, cond, self.strength)
        return eta, log_q0 - logdet


class FlowPosteriorFixedBase(nn.Module):
    fixed_base = True
    def __init__(self, base, n_eta):
        super().__init__()
        self.base = base
        self.amortized = base.amortized
        self.flow = ConditionalFlow(n_eta, 2*n_eta)
        self.strength = 1.0
    def rsample_and_logq(self, batch, K, drep=False):
        mu, log_s = self.base.params(batch)
        z0 = torch.randn((K,) + mu.shape, device=mu.device, dtype=mu.dtype)
        log_q0 = (-0.5*z0**2 - 0.5*math.log(2*math.pi)).sum(-1)
        cond = torch.cat([mu, log_s], -1).unsqueeze(0).expand(K, -1, -1)
        eta, logdet = self.flow(z0, cond, self.strength)
        return eta, log_q0 - logdet


def make_posterior(kind, family, n_subj, n_eta, device, encoder_input_dim=None):
    if kind not in {"free", "amortized"}:
        raise ValueError("posterior must be 'free' or 'amortized'")
    if kind == "free":
        base = FreePosterior(n_subj, n_eta)
    else:
        if encoder_input_dim is None:
            raise ValueError("encoder_input_dim is required for an amortized posterior")
        base = AmortizedPosterior(encoder_input_dim, n_eta)
    if family == "gaussian":
        q = base
    elif family == "flow":
        q = FlowPosterior(base, n_eta)
    elif family == "flow_fixedbase":
        q = FlowPosteriorFixedBase(base, n_eta)
    else:
        raise ValueError("family must be 'gaussian', 'flow', or 'flow_fixedbase'")
    return q.to(device)
