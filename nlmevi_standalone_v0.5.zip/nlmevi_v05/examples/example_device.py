"""Minimal demonstration of automatic CPU/CUDA device selection."""
from nlmevi import IWVI

# This configuration can be passed directly to nlmevi(...).
# CUDA is used if available; otherwise CPU is used.
est = IWVI(
    posterior="amortized",
    family="gaussian",
    K=8,
    device="auto",
)

print("Requested device:", est.device)
print("After fitting, inspect fit.device to see the resolved device.")
