"""
Phase 2 / DeltaOFV: is the recovered likelihood actually usable for model selection?
=====================================================================================

THE QUESTION THIS SCRIPT ANSWERS:

    is_marginal_loglik (nlmevi_core) gives an importance-sampling estimate of
    the marginal log-likelihood, on NONMEM's OFV scale. That's necessary but
    not sufficient for claiming "you can run a likelihood-ratio test with
    this." This script checks that claim directly: simulate data under a
    known NULL, fit nested models, and see whether the empirical distribution
    of dOFV = OFV_reduced - OFV_full matches its theoretical reference.

    If it doesn't, the likelihood recovery is not yet fit for model
    selection, regardless of how good the point estimates look.

THE STATISTICAL SUBTLETY THIS SCRIPT DOES NOT SKIP:

    The nested comparison here is FULL model (3 random effects: eta_CL,
    eta_V, eta_Ka) vs REDUCED model (2 random effects: eta_CL, eta_V; ka has
    NO between-subject variability). This is a test of whether a variance
    component (om_Ka) is zero.

    A naive analyst reaches for dOFV ~ chi-square(df=1) here. That is WRONG.
    Testing a variance against the boundary of its parameter space (Var >= 0)
    is a non-regular problem: under the null, the MLE of the variance is at
    the boundary (0) roughly half the time, which point-masses half the null
    distribution's probability at dOFV = 0. The correct asymptotic reference
    (Self & Liang 1987, Case 5) is a 50:50 MIXTURE of a point mass at 0 and
    chi-square(df=1), NOT plain chi-square(df=1). This is the same subtlety
    that applies when testing OMEGA=0 in NONMEM. Calibrating against plain
    chi-square(1) here would make the test falsely conservative and the
    reported "validation" would be wrong even if it looked reassuring.

    This script calibrates against the correct mixture reference and reports
    both: (a) the fraction of null replicates landing at the boundary
    (should be ~50%), and (b) whether the strictly-positive dOFV values
    among the rest follow chi-square(1) (KS test + QQ data).

DESIGN
    - Simulate N replicates under the REDUCED model (true om_Ka = 0 --
      i.e., ka has zero between-subject variability, generated via
      nlmevi_core.simulate with TrueParams.om_ka=0.0).
    - Fit BOTH models to each replicate:
        reduced: OneCmtOralNoKaRE (n_eta=2, 6 population params)
        full:    OneCmtOral        (n_eta=3, 7 population params)
    - dOFV = -2*(ll_reduced - ll_full) = OFV_reduced - OFV_full
    - Compare the empirical distribution of dOFV to the Self-Liang mixture.

REQUIRES  nlmevi_core.py in the same directory.
"""

# %% ---------------------------------------------------------------- imports
import argparse
import math
import time

import numpy as np
import pandas as pd
import torch
from scipy import stats
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from nlmevi_core import (
    TrueParams, OneCmtOral, simulate, to_tensors, fit_model, conc_analytic,
)

torch.set_default_dtype(torch.float64)


# %% ------------------------------------------------- the reduced model
class OneCmtOralNoKaRE:
    """
    Identical to OneCmtOral except ka has NO random effect: only eta_CL and
    eta_V are estimated (n_eta=2). ka is a pure fixed effect.

    theta (log scale, 6 params instead of 7):
        [log CL, log V, log ka, log om_CL, log om_V, log sigma]

    This is the REDUCED model in the nested comparison. Note it still
    ACCEPTS a 3-column eta tensor's worth of noise from upstream samplers if
    ever reused generically -- but here n_eta=2 so the posterior samplers
    (make_posterior) correctly allocate only 2 random effects, keeping the
    parameter count difference between reduced (6) and full (7) exactly 1,
    which is what makes df=1 the right reference.
    """
    n_eta = 2
    n_theta = 6

    def __init__(self, dose):
        self.dose = dose

    @staticmethod
    def unpack(theta):
        tv = theta[:3]              # log CL, log V, log ka (ka has no eta)
        om = torch.exp(theta[3:5])  # om_CL, om_V only
        sigma = torch.exp(theta[5])
        return tv, om, sigma

    def log_prior(self, eta, theta):
        _, om, _ = self.unpack(theta)
        return (-0.5 * (eta / om) ** 2 - torch.log(om) - 0.5 * math.log(2 * math.pi)).sum(-1)

    def predict(self, eta, theta, t):
        tv, _, _ = self.unpack(theta)
        CL = torch.exp(tv[0] + eta[..., 0:1])
        V = torch.exp(tv[1] + eta[..., 1:2])
        ka = torch.exp(tv[2])   # no eta -- identical for every subject/sample
        return conc_analytic(t, CL, V, ka, self.dose)

    def log_lik(self, logy, eta, theta, t, mask):
        _, _, sigma = self.unpack(theta)
        pred = self.predict(eta, theta, t).clamp_min(1e-12)
        resid = logy - torch.log(pred)
        ll = -0.5 * (resid / sigma) ** 2 - torch.log(sigma) - 0.5 * math.log(2 * math.pi)
        return (ll * mask).sum(-1)

    def log_joint(self, logy, eta, theta, t, mask):
        return self.log_prior(eta, theta) + self.log_lik(logy, eta, theta, t, mask)


# %% ------------------------------------------------------------ experiment
def run_null_calibration(n_reps, n_subj, K, max_steps, out, seed0=5000):
    """
    Simulates n_reps null datasets (true om_Ka = 0), fits reduced and full
    models to each, and returns the per-replicate dOFV plus both models'
    parameter estimates for diagnostic purposes.
    """
    tp = TrueParams()
    tp.om_ka = 0.0    # THE NULL: no true ka variability
    times = [0.5, 1.0, 2.0, 4.0, 8.0, 24.0]

    theta_reduced_init = [math.log(2.0), math.log(20.0), math.log(0.8),
                          math.log(0.3), math.log(0.3), math.log(0.3)]
    theta_full_init = [math.log(2.0), math.log(20.0), math.log(0.8),
                       math.log(0.3), math.log(0.3), math.log(0.3), math.log(0.3)]

    model_reduced = OneCmtOralNoKaRE(tp.dose)
    model_full = OneCmtOral(tp.dose)

    rows = []
    for rep in range(n_reps):
        seed = seed0 + rep
        data = simulate(tp, n_subj, times, seed=seed)   # ONE dataset for both fits

        t0 = time.time()
        _, _, ll_red, _, _, n_run_r, conv_r = fit_model(
            model_reduced, data, "free", "gaussian", K, theta_reduced_init,
            n_eta=2, max_steps=max_steps,
        )
        _, _, ll_full, _, _, n_run_f, conv_f = fit_model(
            model_full, data, "free", "gaussian", K, theta_full_init,
            n_eta=3, max_steps=max_steps,
        )
        dofv = -2 * (ll_red - ll_full)   # OFV_reduced - OFV_full

        rows.append(dict(
            replicate=rep, seed=seed, ll_reduced=ll_red, ll_full=ll_full,
            dofv=dofv, converged_reduced=conv_r, converged_full=conv_f,
            n_steps_reduced=n_run_r, n_steps_full=n_run_f,
            secs=time.time() - t0,
        ))
        flag = "" if (conv_r and conv_f) else "  *** CONVERGENCE ISSUE ***"
        print(f"  rep {rep:3d} | ll_reduced {ll_red:8.2f} | ll_full {ll_full:8.2f} | "
              f"dOFV {dofv:+7.3f} | {time.time()-t0:5.1f}s{flag}")

    return pd.DataFrame(rows)


def calibrate(df, out):
    """
    Compares the empirical dOFV distribution to the Self-Liang (1987)
    boundary mixture: 0.5 * point-mass-at-0 + 0.5 * chi-square(df=1).

    Under a correctly-behaving likelihood:
      - roughly HALF of replicates should show dOFV <= ~0 (the reduced
        model's om_Ka estimate hit or near the boundary -- adding the extra
        random effect didn't help, as it shouldn't under the true null)
      - the other half, dOFV should follow chi-square(1)
    """
    dofv = df.dofv.values
    n = len(dofv)

    frac_at_boundary = np.mean(dofv <= 0.05)   # small tolerance for optimizer noise
    print("\n" + "=" * 72)
    print("CALIBRATION -- comparing empirical dOFV to the Self-Liang mixture")
    print("=" * 72)
    print(f"  N replicates: {n}")
    print(f"  Fraction with dOFV <= 0 (should be ~50% under the mixture, "
          f"NOT under plain chi-sq(1)): {100*frac_at_boundary:.1f}%")

    positive = dofv[dofv > 0.05]
    if len(positive) >= 10:
        # KS test: do the strictly-positive dOFV values follow chi-square(1)?
        ks_stat, ks_p = stats.kstest(positive, "chi2", args=(1,))
        print(f"  KS test of positive dOFV vs chi-square(1): "
              f"stat={ks_stat:.4f}, p={ks_p:.4f}  "
              f"{'PASS (fail to reject)' if ks_p > 0.05 else 'FAIL -- reference mismatch'}")
    else:
        print("  Too few positive-dOFV replicates for a KS test -- increase --reps")
        ks_p = None

    # Contrast: naive (WRONG) reference vs the correct Self-Liang mixture
    # reference, both at nominal alpha=0.05.
    #   - Naive analyst tests dOFV against chi-square(1)'s 95th percentile.
    #     Under the TRUE mixture null, P(dOFV > chi2.ppf(0.95,1)) =
    #     0.5 * P(chi2(1) > chi2.ppf(0.95,1)) = 0.5*0.05 = 2.5%, not 5% --
    #     the naive test is silently conservative (underpowered), not merely
    #     "a bit off."
    #   - Correct mixture test rejects at chi2.ppf(0.90,1) instead (Self &
    #     Liang 1987): P(dOFV > chi2.ppf(0.90,1)) = 0.5*P(chi2(1)>chi2.ppf(0.90,1))
    #     = 0.5*0.10 = 5%, exactly nominal.
    naive_cutoff = stats.chi2.ppf(0.95, df=1)
    correct_cutoff = stats.chi2.ppf(0.90, df=1)
    naive_reject_rate = np.mean(dofv > naive_cutoff)
    correct_reject_rate = np.mean(dofv > correct_cutoff)
    print(f"\n  Naive (WRONG) test -- reject if dOFV > chi2.ppf(0.95,1)={naive_cutoff:.3f}:")
    print(f"    empirical type-I error = {100*naive_reject_rate:.1f}%  "
          f"(true value under the mixture is 2.5%, not the intended 5% -- "
          f"this is why 'just use chi-square(1)' quietly under-powers the test)")
    print(f"  Correct (Self-Liang) test -- reject if dOFV > chi2.ppf(0.90,1)={correct_cutoff:.3f}:")
    print(f"    empirical type-I error = {100*correct_reject_rate:.1f}%  (target: 5%)")

    verdict_ok = abs(frac_at_boundary - 0.5) < 0.15 and (ks_p is None or ks_p > 0.01)
    print("\n" + "-" * 72)
    if verdict_ok:
        print("VERDICT: dOFV is well-calibrated against the correct boundary-mixture")
        print("reference. Likelihood-ratio tests using this likelihood recovery are")
        print("trustworthy for this class of comparison (testing a variance component).")
    else:
        print("VERDICT: dOFV does NOT match the expected reference. Do not use this")
        print("likelihood recovery for LRTs yet -- something in the marginal-likelihood")
        print("estimate (K, convergence, or the IS proposal itself) needs attention")
        print("before it can be trusted for model selection claims.")

    # Figure: empirical dOFV histogram vs the mixture density
    fig, ax = plt.subplots(figsize=(7, 5))
    ax.hist(dofv, bins=30, density=True, alpha=0.6, label="empirical dOFV")
    xx = np.linspace(0.01, max(dofv.max(), 8), 300)
    ax.plot(xx, 0.5 * stats.chi2.pdf(xx, df=1), "r-", lw=2,
           label="0.5 x chi-sq(1) density (positive half of the mixture)")
    ax.axvline(0, color="k", ls="--", alpha=0.5)
    ax.set_xlabel("dOFV = OFV_reduced - OFV_full")
    ax.set_ylabel("density")
    ax.set_title(f"dOFV calibration under H0 (true om_Ka=0)\n"
                 f"{100*frac_at_boundary:.0f}% at boundary (target ~50%)")
    ax.legend()
    ax.grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig(f"{out}/phase2_deltaofv_calibration.png", dpi=150)
    print(f"\nFigure -> {out}/phase2_deltaofv_calibration.png")

    return verdict_ok


# %% ------------------------------------------------------------------ main
if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--reps", type=int, default=100,
                    help="more reps = more power to detect miscalibration; "
                         "the KS test needs at least ~30-50 positive-dOFV reps")
    ap.add_argument("--subjects", type=int, default=120)
    ap.add_argument("--K", type=int, default=64,
                    help="use the best-corrected VI arm (high K) for this check "
                         "-- calibration should be tested on the arm you'd "
                         "actually report, not the known-biased K=1 arm")
    ap.add_argument("--max-steps", type=int, default=25000)
    ap.add_argument("--out", default="/mnt/user-data/outputs")
    args = ap.parse_args()

    print("=" * 72)
    print(f"dOFV NULL CALIBRATION  N={args.subjects}  reps={args.reps}  K={args.K}")
    print("True model: om_Ka = 0 (reduced model is correctly specified)")
    print("=" * 72)

    df = run_null_calibration(args.reps, args.subjects, args.K, args.max_steps, args.out)
    df.to_csv(f"{args.out}/phase2_deltaofv_results.csv", index=False)
    calibrate(df, args.out)
    print(f"\nRaw results -> {args.out}/phase2_deltaofv_results.csv")
