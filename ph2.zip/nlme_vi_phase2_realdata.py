"""
Phase 2 / real data: does the shrinkage signature show up outside simulation?
================================================================================

Every result so far is on simulated data with known ground truth. This
script applies the same VI machinery to a REAL oral-PK dataset -- but
because there's no ground truth on real data, the check here is different
from Phase 0/1: instead of bias-vs-truth, we look for the SAME SIGNATURE
found on simulated data: K=1 (plain ELBO) reporting visibly smaller
between-subject variability than K=high (IW-ELBO), on the identical dataset.
That's the pattern a reviewer familiar with Tarek & Afonso's warfarin table
will recognize immediately.

DATA SOURCES

    Theophylline: loaded directly, no CSV needed --
        pip install rdatasets
        python nlme_vi_phase2_realdata.py --dataset theoph
    This is the actual Boeckmann/Sheiner/Beal data (verified: 132 rows, 12
    subjects, matches the canonical dataset) via the `rdatasets` package,
    which mirrors R's datasets programmatically -- not retyped from memory,
    so no transcription-error risk.

    Warfarin: NOT available through rdatasets or any other Python package
    checked (it lives in the specialized `nlmixr2data` R package, which
    general-purpose R-dataset mirrors don't index). Export it from R:
        write.csv(nlmixr2data::warfarin, "warfarin.csv", row.names = FALSE)
    then point --csv at it with --col-map to match column names (see below)
    -- no need to hand-edit the file or this script.

    Any other CSV: --csv plus --col-map.

EXPECTED INTERNAL FORMAT (after loading/renaming, long format):
    subject, time, conc, dose
    Different subjects may have different numbers of observations (ragged
    designs are handled via padding + mask) and different doses.

--col-map lets you point --csv at a file with different column names
without editing anything, e.g. for a raw nlmixr2data::warfarin export
(columns typically ID, TIME, DV, AMT or similar -- check your file and
adjust):
    --col-map "ID=subject,TIME=time,DV=conc,AMT=dose"

REQUIRES  nlmevi_core.py in the same directory.
"""

import argparse

import numpy as np
import pandas as pd
import torch
import math

from nlmevi_core import OneCmtOral, fit_model

torch.set_default_dtype(torch.float64)


# %% --------------------------------------------------------- data loading
def load_theoph():
    """
    Loads the real Boeckmann/Sheiner/Beal theophylline dataset via the
    `rdatasets` package (pip install rdatasets) -- programmatically sourced,
    not retyped, so no transcription-error risk. Verified against the
    canonical dataset: 132 rows, 12 subjects.
    """
    try:
        import rdatasets
    except ImportError:
        raise ImportError(
            "pip install rdatasets   (then re-run with --dataset theoph)"
        )
    df = rdatasets.data("datasets", "Theoph")
    return df.rename(columns={"Subject": "subject", "Time": "time", "Dose": "dose"})
    # 'conc' column name already matches; 'Wt' and 'rownames' are simply
    # ignored downstream since load_real_data only reads the 4 required columns


def apply_col_map(df, col_map_str):
    """--col-map 'ID=subject,TIME=time,DV=conc,AMT=dose' -> renames those
    columns in place. Silently ignores mappings for columns not present."""
    if not col_map_str:
        return df
    mapping = {}
    for pair in col_map_str.split(","):
        src, dst = pair.split("=")
        mapping[src.strip()] = dst.strip()
    return df.rename(columns=mapping)


def load_real_data(df):
    """
    Takes a dataframe already containing (subject, time, conc, dose) columns
    -- from load_theoph(), a --csv + --col-map, or hand-built -- and pads to
    a common (N, T_max) shape with a mask for ragged designs, since real
    data rarely has every subject sampled at the same times.

    Returns (data_dict, dose_per_subject, subject_ids) where data_dict has
    the same 'logy'/'t'/'mask' keys nlmevi_core.to_tensors expects.
    """
    required = {"subject", "time", "conc", "dose"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"Data missing required columns: {missing}. "
                         f"Found: {list(df.columns)}. Use --col-map to rename "
                         f"columns from your source file without editing it.")

    # Drop non-positive concentrations (typically pre-dose t=0 samples, which
    # the model already predicts as exactly 0 by construction -- they carry
    # no fitting information and can't be log-transformed). This is NOT the
    # right move for genuine below-quantification-limit (BLQ) censoring
    # during the elimination phase -- that needs proper M3/M4 handling, not
    # implemented here. Printed explicitly so it's never a silent decision.
    n_before = len(df)
    bad = df[df.conc <= 0]
    if len(bad) > 0:
        print(f"  Dropping {len(bad)} non-positive concentration rows "
              f"(subjects: {sorted(bad.subject.unique().tolist())}) -- "
              f"if these are BLQ censoring rather than pre-dose baselines, "
              f"this simple drop is NOT appropriate; implement M3/M4 instead.")
        df = df[df.conc > 0].copy()
    print(f"  {len(df)}/{n_before} rows retained")

    subjects = df.subject.unique()
    n_subj = len(subjects)
    n_obs_max = df.groupby("subject").size().max()

    logy = np.full((n_subj, n_obs_max), np.nan)
    t = np.zeros((n_subj, n_obs_max))
    mask = np.zeros((n_subj, n_obs_max))
    dose = np.zeros(n_subj)

    for i, sid in enumerate(subjects):
        sub = df[df.subject == sid].sort_values("time")
        n = len(sub)
        conc = sub.conc.values.astype(float)
        logy[i, :n] = np.log(conc)
        t[i, :n] = sub.time.values
        mask[i, :n] = 1.0
        dose[i] = sub.dose.iloc[0]

    if len(np.unique(dose)) > 1:
        print(f"  NOTE: doses vary across subjects ({sorted(np.unique(dose))}). "
              f"Handled correctly: OneCmtOral's arithmetic broadcasts fine "
              f"against a per-subject dose tensor (verified: doubling one "
              f"subject's dose exactly doubles their predicted concentration "
              f"while leaving others unchanged) -- run_real_data_comparison "
              f"below passes dose as a (N,1) tensor rather than a scalar.")

    logy = np.nan_to_num(logy, nan=0.0)   # masked positions; value unused
    data = dict(logy=logy, t=t, mask=mask)
    return data, dose, subjects


def make_synthetic_placeholder(n_subj=12, seed=0):
    """
    NOT REAL DATA. Generates a small synthetic oral-PK dataframe purely so
    this script's loading/fitting pipeline can be exercised without a real
    dataset on hand. Use --dataset theoph or --csv for any actual result.
    """
    from nlmevi_core import TrueParams, simulate
    tp = TrueParams()
    times = [0.5, 1.0, 2.0, 4.0, 8.0, 24.0]
    d = simulate(tp, n_subj, times, seed=seed)
    rows = []
    for i in range(n_subj):
        for j, tt in enumerate(times):
            rows.append(dict(subject=i + 1, time=tt,
                            conc=math.exp(d["logy"][i, j]), dose=tp.dose))
    print("  [placeholder] using SYNTHETIC (not real) data")
    return pd.DataFrame(rows)


# %% ------------------------------------------------------------ experiment
def run_real_data_comparison(df, K_grid, max_steps, out):
    data, dose, subjects = load_real_data(df)
    n_subj = len(subjects)
    print(f"Loaded {n_subj} subjects")

    # Per-subject dose tensor, shape (N,1) -- OneCmtOral's arithmetic
    # broadcasts against this exactly like it does against CL/V/ka, so
    # varying real-world doses (e.g. Theoph's weight-adjusted mg/kg dosing)
    # are handled correctly without restricting to a single-dose subset.
    dose_tensor = torch.as_tensor(dose, dtype=torch.float64).unsqueeze(-1)
    model = OneCmtOral(dose_tensor)
    theta_init = [math.log(2.0), math.log(20.0), math.log(0.8),
                 math.log(0.3), math.log(0.3), math.log(0.3), math.log(0.3)]

    rows = []
    for K in K_grid:
        theta, q, ll, ess, top, n_run, converged = fit_model(
            model, data, "free", "gaussian", K, theta_init, n_eta=3,
            max_steps=max_steps,
        )
        est = np.concatenate([np.exp(theta[:3]), np.exp(theta[3:6]), [np.exp(theta[6])]])
        rows.append(dict(K=K, CL=est[0], V=est[1], ka=est[2],
                        om_CL=est[3], om_V=est[4], om_ka=est[5], sigma=est[6],
                        ofv=-2 * ll, mean_ess=float(ess.mean()),
                        n_steps=n_run, converged=converged))
        flag = "" if converged else "  *** DID NOT CONVERGE ***"
        print(f"  K={K:3d} | om_CL {est[3]:.3f} om_V {est[4]:.3f} om_ka {est[5]:.3f} | "
              f"OFV {-2*ll:8.1f} | steps={n_run}{flag}")

    results_df = pd.DataFrame(rows)
    results_df.to_csv(f"{out}/phase2_realdata_results.csv", index=False)
    return results_df


def summarize(df):
    print("\n" + "=" * 72)
    print("K=1 (plain ELBO) vs K=high (IW-ELBO): the signature to look for")
    print("=" * 72)
    k_lo, k_hi = df.K.min(), df.K.max()
    lo = df[df.K == k_lo].iloc[0]
    hi = df[df.K == k_hi].iloc[0]
    for p in ["om_CL", "om_V", "om_ka"]:
        rel = 100 * (lo[p] - hi[p]) / hi[p]
        print(f"  {p}: K={k_lo} -> {lo[p]:.3f}   K={k_hi} -> {hi[p]:.3f}   "
              f"(K={k_lo} is {rel:+.1f}% relative to K={k_hi})")
    print(f"\n  OFV: K={k_lo} -> {lo.ofv:.1f}   K={k_hi} -> {hi.ofv:.1f}")
    print("\nIf K=1's omegas are consistently smaller than K=high's (negative %")
    print("above), that's the same shrinkage signature found on simulated data,")
    print("now on real data where FOCE/SAEM (via phase2_baselines.py) is the")
    print("external reference to compare both arms against.")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset", choices=["theoph"], default=None,
                    help="load a real dataset directly (no CSV needed); "
                         "requires: pip install rdatasets")
    ap.add_argument("--csv", default=None,
                    help="path to a real long-format CSV. Use --col-map if "
                         "its columns aren't already named subject,time,conc,dose "
                         "(e.g. a raw nlmixr2data::warfarin export).")
    ap.add_argument("--col-map", default=None,
                    help="e.g. 'ID=subject,TIME=time,DV=conc,AMT=dose'")
    ap.add_argument("--K", default="1,64")
    ap.add_argument("--max-steps", type=int, default=25000)
    ap.add_argument("--out", default="/mnt/user-data/outputs")
    args = ap.parse_args()

    if args.dataset == "theoph":
        print("Loading the real Theophylline dataset via rdatasets...")
        data_df = load_theoph()
    elif args.csv:
        data_df = apply_col_map(pd.read_csv(args.csv), args.col_map)
    else:
        print("*** No --dataset or --csv given: generating a SYNTHETIC placeholder. ***")
        print("*** This validates the pipeline only -- NOT a real-data result. ***")
        print("*** Use --dataset theoph for real data, or --csv for your own. ***\n")
        data_df = make_synthetic_placeholder()

    K_grid = [int(k) for k in args.K.split(",")]
    df = run_real_data_comparison(data_df, K_grid, args.max_steps, args.out)
    summarize(df)
    print(f"\nRaw results -> {args.out}/phase2_realdata_results.csv")
