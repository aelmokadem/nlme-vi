"""Lightweight clinical-data preparation for nlmevi.

Expected long-format columns are configurable, with conventional defaults:
ID, TIME, DV, EVID, AMT, CMT.

This is intentionally not a NONMEM-compatible event engine. It handles the
common reusable subset: irregular observations, subject-specific/repeated
bolus or extravascular doses, missing DV, and baseline covariates.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable, Sequence
import numpy as np
import pandas as pd


@dataclass
class NLMEData:
    ids: np.ndarray
    logy: np.ndarray
    t: np.ndarray
    mask: np.ndarray
    dose_time: np.ndarray
    dose_amt: np.ndarray
    dose_mask: np.ndarray
    covariates: np.ndarray | None = None
    covariate_names: tuple[str, ...] = ()

    @property
    def n_subjects(self) -> int:
        return int(self.logy.shape[0])

    @property
    def n_observations_max(self) -> int:
        return int(self.logy.shape[1])

    def as_dict(self) -> dict:
        out = {
            "logy": self.logy,
            "t": self.t,
            "mask": self.mask,
            "dose_time": self.dose_time,
            "dose_amt": self.dose_amt,
            "dose_mask": self.dose_mask,
        }
        if self.covariates is not None:
            out["covariates"] = self.covariates
        return out


def _pad(rows: list[np.ndarray], fill: float = 0.0) -> np.ndarray:
    width = max((len(x) for x in rows), default=0)
    out = np.full((len(rows), width), fill, dtype=float)
    for i, x in enumerate(rows):
        out[i, : len(x)] = x
    return out


def prepare_data(
    df: pd.DataFrame,
    *,
    id_col: str = "ID",
    time_col: str = "TIME",
    dv_col: str = "DV",
    evid_col: str = "EVID",
    amt_col: str = "AMT",
    cmt_col: str = "CMT",
    covariates: Sequence[str] | None = None,
    log_transform_dv: bool = True,
) -> NLMEData:
    """Convert a conventional long clinical dataset to padded subject arrays.

    Rules:
      * EVID==0 and non-missing DV -> observation row.
      * EVID!=0 and AMT>0 -> dose row.
      * rows are sorted by TIME within subject.
      * covariates are currently treated as baseline subject-level values
        (the first non-missing value per subject).
    """
    required = {id_col, time_col, dv_col}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"Missing required columns: {sorted(missing)}")

    work = df.copy()
    if evid_col not in work:
        work[evid_col] = np.where(work[dv_col].notna(), 0, 1)
    if amt_col not in work:
        work[amt_col] = 0.0
    if cmt_col not in work:
        work[cmt_col] = 1

    work = work.sort_values([id_col, time_col], kind="stable")
    ids = pd.unique(work[id_col])

    obs_t, obs_y, obs_mask = [], [], []
    dose_t, dose_a, dose_m = [], [], []
    cov_rows = []
    covariates = tuple(covariates or ())

    for sid in ids:
        g = work[work[id_col] == sid]
        obs = g[(g[evid_col] == 0) & g[dv_col].notna()]
        y = obs[dv_col].to_numpy(float)
        if log_transform_dv:
            if np.any(y <= 0):
                raise ValueError("DV must be > 0 when log_transform_dv=True")
            y = np.log(y)
        obs_t.append(obs[time_col].to_numpy(float))
        obs_y.append(y)
        obs_mask.append(np.ones(len(obs), dtype=float))

        dos = g[(g[evid_col] != 0) & g[amt_col].notna() & (g[amt_col] > 0)]
        dose_t.append(dos[time_col].to_numpy(float))
        dose_a.append(dos[amt_col].to_numpy(float))
        dose_m.append(np.ones(len(dos), dtype=float))

        if covariates:
            vals = []
            for col in covariates:
                if col not in g:
                    raise ValueError(f"Missing covariate column: {col}")
                nonmiss = g[col].dropna()
                if nonmiss.empty:
                    raise ValueError(f"Subject {sid!r} has no value for covariate {col}")
                vals.append(float(nonmiss.iloc[0]))
            cov_rows.append(vals)

    if max((len(x) for x in obs_t), default=0) == 0:
        raise ValueError("No observation rows found")

    result = NLMEData(
        ids=np.asarray(ids),
        logy=_pad(obs_y),
        t=_pad(obs_t),
        mask=_pad(obs_mask),
        dose_time=_pad(dose_t),
        dose_amt=_pad(dose_a),
        dose_mask=_pad(dose_m),
        covariates=np.asarray(cov_rows, dtype=float) if covariates else None,
        covariate_names=covariates,
    )
    return result
