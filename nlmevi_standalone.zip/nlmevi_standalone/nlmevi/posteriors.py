"""Variational posterior families used by IWVI."""
from __future__ import annotations
import math
import torch
import torch.nn as nn


class FreePosterior(nn.Module):
    amortized = False
    def __init__(self, n_subj: int, n_eta: int):
        super().__init__()
        self.mu = nn.Parameter(torch.zeros(n_subj, n_eta))
        self.log_s = nn.Parameter(torch.full((n_subj, n_eta), -1.0))

    def params(self, batch):
        return self.mu, self.log_s

    def rsample_and_logq(self, batch, K: int, drep: bool = False):
        mu, log_s = self.params(batch)
        s = torch.exp(log_s)
        eps = torch.randn((K,) + mu.shape, device=mu.device, dtype=mu.dtype)
        eta = mu + s * eps
        if drep:
            mu_d, s_d = mu.detach(), s.detach()
            z = (eta - mu_d) / s_d
            log_q = (-0.5*z**2 - torch.log(s_d) - 0.5*math.log(2*math.pi)).sum(-1)
        else:
            log_q = (-0.5*eps**2 - torch.log(s) - 0.5*math.log(2*math.pi)).sum(-1)
        return eta, log_q


class AmortizedPosterior(nn.Module):
    amortized = True
    def __init__(self, n_obs: int, n_eta: int, hidden: int = 32):
        super().__init__()
        # logDV, normalized time, and observation mask.
        self.net = nn.Sequential(
            nn.Linear(3*n_obs, hidden), nn.Tanh(),
            nn.Linear(hidden, hidden), nn.Tanh(),
            nn.Linear(hidden, 2*n_eta),
        )
        self.n_eta = n_eta

    def params(self, batch):
        denom = batch["t"].max().clamp_min(1.0)
        x = torch.cat([batch["logy"] * batch["mask"], batch["t"]/denom, batch["mask"]], dim=-1)
        out = self.net(x)
        mu, log_s = out[..., :self.n_eta], out[..., self.n_eta:]
        return mu, log_s.clamp(-5.0, 2.0)

    rsample_and_logq = FreePosterior.rsample_and_logq


class AffineCoupling(nn.Module):
    def __init__(self, dim, cond_dim, hidden=16, mask_first_half=True):
        super().__init__()
        self.d1 = dim // 2 if dim > 1 else 1
        self.d2 = dim - self.d1
        self.mask_first_half = mask_first_half
        in_dim = (self.d1 if mask_first_half else self.d2) + cond_dim
        out_dim = 2 * (self.d2 if mask_first_half else self.d1)
        self.net = nn.Sequential(nn.Linear(in_dim, hidden), nn.Tanh(), nn.Linear(hidden, out_dim))
        nn.init.zeros_(self.net[-1].weight)
        nn.init.zeros_(self.net[-1].bias)

    def forward(self, z, cond, strength=1.0):
        z1, z2 = z[..., :self.d1], z[..., self.d1:]
        if self.mask_first_half:
            log_s, shift = self.net(torch.cat([z1, cond], -1)).chunk(2, -1)
            log_s = strength * 0.5 * torch.tanh(log_s)
            shift = strength * shift
            z2 = z2 * torch.exp(log_s) + shift
            return torch.cat([z1, z2], -1), log_s.sum(-1)
        log_s, shift = self.net(torch.cat([z2, cond], -1)).chunk(2, -1)
        log_s = strength * 0.5 * torch.tanh(log_s)
        shift = strength * shift
        z1 = z1 * torch.exp(log_s) + shift
        return torch.cat([z1, z2], -1), log_s.sum(-1)


class ConditionalFlow(nn.Module):
    def __init__(self, dim, cond_dim, n_layers=2, hidden=16):
        super().__init__()
        self.layers = nn.ModuleList([
            AffineCoupling(dim, cond_dim, hidden, i % 2 == 0) for i in range(n_layers)
        ])
    def forward(self, z, cond, strength=1.0):
        ld = torch.zeros(z.shape[:-1], device=z.device, dtype=z.dtype)
        for layer in self.layers:
            z, inc = layer(z, cond, strength)
            ld = ld + inc
        return z, ld


class FlowPosterior(nn.Module):
    fixed_base = False
    def __init__(self, base, n_eta):
        super().__init__()
        self.base = base
        self.amortized = base.amortized
        self.flow = ConditionalFlow(n_eta, 2*n_eta)
        self.strength = 1.0
    def rsample_and_logq(self, batch, K, drep=False):
        mu, log_s = self.base.params(batch)
        s = torch.exp(log_s)
        eps = torch.randn((K,) + mu.shape, device=mu.device, dtype=mu.dtype)
        z0 = mu + s*eps
        if drep:
            z = (z0 - mu.detach()) / s.detach()
            log_q0 = (-0.5*z**2 - torch.log(s.detach()) - 0.5*math.log(2*math.pi)).sum(-1)
        else:
            log_q0 = (-0.5*eps**2 - torch.log(s) - 0.5*math.log(2*math.pi)).sum(-1)
        cond = torch.cat([mu.detach(), log_s.detach()], -1).unsqueeze(0).expand(K, -1, -1)
        eta, logdet = self.flow(z0, cond, self.strength)
        return eta, log_q0 - logdet


class FlowPosteriorFixedBase(nn.Module):
    fixed_base = True
    def __init__(self, base, n_eta):
        super().__init__()
        self.base = base
        self.amortized = base.amortized
        self.flow = ConditionalFlow(n_eta, 2*n_eta)
        self.strength = 1.0
    def rsample_and_logq(self, batch, K, drep=False):
        mu, log_s = self.base.params(batch)
        z0 = torch.randn((K,) + mu.shape, device=mu.device, dtype=mu.dtype)
        log_q0 = (-0.5*z0**2 - 0.5*math.log(2*math.pi)).sum(-1)
        cond = torch.cat([mu, log_s], -1).unsqueeze(0).expand(K, -1, -1)
        eta, logdet = self.flow(z0, cond, self.strength)
        return eta, log_q0 - logdet


def make_posterior(kind, family, n_subj, n_obs, n_eta, device):
    if kind not in {"free", "amortized"}:
        raise ValueError("posterior must be 'free' or 'amortized'")
    base = FreePosterior(n_subj, n_eta) if kind == "free" else AmortizedPosterior(n_obs, n_eta)
    if family == "gaussian":
        q = base
    elif family == "flow":
        q = FlowPosterior(base, n_eta)
    elif family == "flow_fixedbase":
        q = FlowPosteriorFixedBase(base, n_eta)
    else:
        raise ValueError("family must be 'gaussian', 'flow', or 'flow_fixedbase'")
    return q.to(device)
