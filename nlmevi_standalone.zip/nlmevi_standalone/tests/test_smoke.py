import numpy as np
import pandas as pd
from nlmevi import prepare_data, OneCmtOralEvents, IWVI, nlmevi


def tiny_data():
    rows = []
    for sid in [1, 2, 3]:
        rows.append(dict(ID=sid, TIME=0.0, EVID=1, AMT=100.0, CMT=1, DV=np.nan))
        for t, dv in [(1.0, 2.0), (4.0, 1.5), (8.0, 0.9)]:
            rows.append(dict(ID=sid, TIME=t, EVID=0, AMT=0.0, CMT=2, DV=dv*(1+0.03*sid)))
    return pd.DataFrame(rows)


def test_prepare_data_shapes():
    d = prepare_data(tiny_data())
    assert d.logy.shape == (3, 3)
    assert d.dose_amt.shape == (3, 1)
    assert np.all(d.mask == 1)


def test_fit_smoke():
    fit = nlmevi(
        OneCmtOralEvents(), tiny_data(),
        est=IWVI(posterior="free", family="gaussian", K=1,
                 adaptive=False, n_steps=20, eval_k=20, seed=1),
    )
    assert len(fit.params) == 7
    assert np.isfinite(fit.loglik)
