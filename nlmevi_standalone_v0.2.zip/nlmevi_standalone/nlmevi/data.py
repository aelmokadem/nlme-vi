"""Lightweight clinical-data preparation for nlmevi.

The likelihood/model side uses compact observation and dose arrays.  The
amortized posterior additionally gets a padded event-feature sequence built
from the original long-format rows.  The feature list is configurable, so the
encoder is not tied to any particular PK dataset.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Sequence
import numpy as np
import pandas as pd


DEFAULT_ENCODER_FEATURES = (
    "TIME", "LOG_DV", "DV_MASK", "EVID", "AMT", "CMT"
)


@dataclass
class NLMEData:
    ids: np.ndarray
    logy: np.ndarray
    t: np.ndarray
    mask: np.ndarray
    dose_time: np.ndarray
    dose_amt: np.ndarray
    dose_mask: np.ndarray
    covariates: np.ndarray | None = None
    covariate_names: tuple[str, ...] = ()
    encoder_x: np.ndarray | None = None          # (subject, event, feature)
    encoder_mask: np.ndarray | None = None       # (subject, event)
    encoder_feature_names: tuple[str, ...] = ()

    @property
    def n_subjects(self) -> int:
        return int(self.logy.shape[0])

    @property
    def n_observations_max(self) -> int:
        return int(self.logy.shape[1])

    @property
    def n_events_max(self) -> int:
        return 0 if self.encoder_x is None else int(self.encoder_x.shape[1])

    def as_dict(self) -> dict:
        out = {
            "logy": self.logy,
            "t": self.t,
            "mask": self.mask,
            "dose_time": self.dose_time,
            "dose_amt": self.dose_amt,
            "dose_mask": self.dose_mask,
        }
        if self.covariates is not None:
            out["covariates"] = self.covariates
        if self.encoder_x is not None:
            out["encoder_x"] = self.encoder_x
            out["encoder_mask"] = self.encoder_mask
        return out


def _pad(rows: list[np.ndarray], fill: float = 0.0) -> np.ndarray:
    width = max((len(x) for x in rows), default=0)
    out = np.full((len(rows), width), fill, dtype=float)
    for i, x in enumerate(rows):
        out[i, : len(x)] = x
    return out


def _pad_2d(rows: list[np.ndarray], n_features: int) -> tuple[np.ndarray, np.ndarray]:
    width = max((x.shape[0] for x in rows), default=0)
    out = np.zeros((len(rows), width, n_features), dtype=float)
    mask = np.zeros((len(rows), width), dtype=float)
    for i, x in enumerate(rows):
        n = x.shape[0]
        out[i, :n, :] = x
        mask[i, :n] = 1.0
    return out, mask


def _encoder_feature_values(
    g: pd.DataFrame,
    feature: str,
    *,
    time_col: str,
    dv_col: str,
    evid_col: str,
    amt_col: str,
    cmt_col: str,
) -> np.ndarray:
    """Return one numeric feature for every original event row.

    Built-in feature names are case-insensitive.  Any other name is treated
    as a numeric column from the input dataframe, which is the extension
    point for arbitrary covariates/design variables.
    """
    key = feature.upper()
    if key == "TIME":
        x = g[time_col].to_numpy(float)
    elif key == "DV":
        x = pd.to_numeric(g[dv_col], errors="coerce").fillna(0.0).to_numpy(float)
    elif key == "LOG_DV":
        dv = pd.to_numeric(g[dv_col], errors="coerce").to_numpy(float)
        x = np.zeros(len(g), dtype=float)
        ok = np.isfinite(dv) & (dv > 0)
        x[ok] = np.log(dv[ok])
    elif key == "DV_MASK":
        x = ((g[evid_col].to_numpy() == 0) & g[dv_col].notna().to_numpy()).astype(float)
    elif key == "EVID":
        x = pd.to_numeric(g[evid_col], errors="coerce").fillna(0.0).to_numpy(float)
    elif key == "AMT":
        x = pd.to_numeric(g[amt_col], errors="coerce").fillna(0.0).to_numpy(float)
    elif key == "CMT":
        x = pd.to_numeric(g[cmt_col], errors="coerce").fillna(0.0).to_numpy(float)
    else:
        if feature not in g.columns:
            raise ValueError(
                f"Unknown encoder feature {feature!r}. Use one of "
                f"{DEFAULT_ENCODER_FEATURES} / 'DV', or provide a numeric dataframe column."
            )
        x = pd.to_numeric(g[feature], errors="coerce").fillna(0.0).to_numpy(float)
    return x


def prepare_data(
    df: pd.DataFrame,
    *,
    id_col: str = "ID",
    time_col: str = "TIME",
    dv_col: str = "DV",
    evid_col: str = "EVID",
    amt_col: str = "AMT",
    cmt_col: str = "CMT",
    covariates: Sequence[str] | None = None,
    encoder_features: Sequence[str] | None = None,
    scale_encoder_features: bool = True,
    log_transform_dv: bool = True,
) -> NLMEData:
    """Convert a conventional long clinical dataset to subject arrays.

    Parameters
    ----------
    encoder_features:
        Per-event inputs supplied to an amortized posterior.  Defaults to
        TIME, LOG_DV, DV_MASK, EVID, AMT, CMT.  In addition to these built-ins
        (and raw DV), *any numeric dataframe column* can be named here, e.g.
        ["TIME", "LOG_DV", "DV_MASK", "EVID", "AMT", "WT", "SEX"].
        Features are built from all rows, including dose-only rows.
    scale_encoder_features:
        If True, divide every non-binary feature by its maximum absolute value
        over valid events.  This is deliberately simple and preserves zeros.
        DV_MASK and EVID are left unchanged.

    Rules
    -----
      * EVID==0 and non-missing DV -> observation row.
      * EVID!=0 and AMT>0 -> dose row.
      * rows are sorted by TIME within subject.
      * covariates are treated as baseline subject-level values (first
        non-missing value per subject) for the model batch.
    """
    required = {id_col, time_col, dv_col}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"Missing required columns: {sorted(missing)}")

    work = df.copy()
    if evid_col not in work:
        work[evid_col] = np.where(work[dv_col].notna(), 0, 1)
    if amt_col not in work:
        work[amt_col] = 0.0
    if cmt_col not in work:
        work[cmt_col] = 1

    work = work.sort_values([id_col, time_col], kind="stable")
    ids = pd.unique(work[id_col])

    obs_t, obs_y, obs_mask = [], [], []
    dose_t, dose_a, dose_m = [], [], []
    cov_rows = []
    enc_rows = []
    covariates = tuple(covariates or ())
    encoder_features = tuple(encoder_features or DEFAULT_ENCODER_FEATURES)

    for sid in ids:
        g = work[work[id_col] == sid]
        obs = g[(g[evid_col] == 0) & g[dv_col].notna()]
        y = obs[dv_col].to_numpy(float)
        if log_transform_dv:
            if np.any(y <= 0):
                raise ValueError("DV must be > 0 when log_transform_dv=True")
            y = np.log(y)
        obs_t.append(obs[time_col].to_numpy(float))
        obs_y.append(y)
        obs_mask.append(np.ones(len(obs), dtype=float))

        dos = g[(g[evid_col] != 0) & g[amt_col].notna() & (g[amt_col] > 0)]
        dose_t.append(dos[time_col].to_numpy(float))
        dose_a.append(dos[amt_col].to_numpy(float))
        dose_m.append(np.ones(len(dos), dtype=float))

        if covariates:
            vals = []
            for col in covariates:
                if col not in g:
                    raise ValueError(f"Missing covariate column: {col}")
                nonmiss = g[col].dropna()
                if nonmiss.empty:
                    raise ValueError(f"Subject {sid!r} has no value for covariate {col}")
                vals.append(float(nonmiss.iloc[0]))
            cov_rows.append(vals)

        cols = [
            _encoder_feature_values(
                g, f, time_col=time_col, dv_col=dv_col, evid_col=evid_col,
                amt_col=amt_col, cmt_col=cmt_col,
            )
            for f in encoder_features
        ]
        enc_rows.append(np.column_stack(cols))

    if max((len(x) for x in obs_t), default=0) == 0:
        raise ValueError("No observation rows found")

    encoder_x, encoder_mask = _pad_2d(enc_rows, len(encoder_features))
    if scale_encoder_features and encoder_x.size:
        # Scale across valid event rows only. Preserve exact 0/1 semantics for
        # the two most common binary indicators.
        for j, name in enumerate(encoder_features):
            if name.upper() in {"DV_MASK", "EVID"}:
                continue
            vals = encoder_x[..., j][encoder_mask.astype(bool)]
            scale = np.max(np.abs(vals)) if vals.size else 1.0
            if np.isfinite(scale) and scale > 0:
                encoder_x[..., j] /= scale

    return NLMEData(
        ids=np.asarray(ids),
        logy=_pad(obs_y),
        t=_pad(obs_t),
        mask=_pad(obs_mask),
        dose_time=_pad(dose_t),
        dose_amt=_pad(dose_a),
        dose_mask=_pad(dose_m),
        covariates=np.asarray(cov_rows, dtype=float) if covariates else None,
        covariate_names=covariates,
        encoder_x=encoder_x,
        encoder_mask=encoder_mask,
        encoder_feature_names=encoder_features,
    )
