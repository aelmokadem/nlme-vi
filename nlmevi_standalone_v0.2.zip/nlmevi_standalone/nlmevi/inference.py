"""IW-ELBO objective, training, diagnostics, and the public nlmevi() API."""
from __future__ import annotations
from dataclasses import dataclass
import copy, math, time
import numpy as np
import pandas as pd
import torch

from .data import NLMEData, prepare_data
from .posteriors import make_posterior, FlowPosterior, FlowPosteriorFixedBase


torch.set_default_dtype(torch.float64)


@dataclass
class IWVI:
    posterior: str = "amortized"
    family: str = "gaussian"
    K: int = 8
    drep: bool = True
    lr: float = 0.05
    adaptive: bool = True
    n_steps: int = 4000
    min_steps: int = 2000
    max_steps: int = 25000
    tol: float = 0.01
    eval_k: int = 4000
    mc_reps: int = 1
    seed: int = 0
    device: str = "cpu"


@dataclass
class NLMEVIFit:
    model: object
    est: IWVI
    theta: np.ndarray
    estimates: np.ndarray
    posterior_object: object
    loglik: float
    ess: np.ndarray
    top_weight_share: np.ndarray
    n_steps: int
    converged: bool
    cpu_seconds: float

    @property
    def params(self):
        return dict(zip(self.model.parameter_names, self.estimates))

    @property
    def omega(self):
        return {self.model.parameter_names[i]: self.estimates[i] for i in self.model.omega_indices}

    def summary(self) -> pd.DataFrame:
        return pd.DataFrame({"parameter": self.model.parameter_names, "estimate": self.estimates})

    def __repr__(self):
        p = ", ".join(f"{k}={v:.4g}" for k, v in self.params.items())
        return (f"NLMEVIFit(posterior={self.est.posterior!r}, family={self.est.family!r}, "
                f"K={self.est.K}, converged={self.converged}, steps={self.n_steps}, "
                f"loglik={self.loglik:.2f})\n  {p}")


def _resolve_device(name: str):
    if name == "auto":
        if torch.cuda.is_available():
            return torch.device("cuda")
        return torch.device("cpu")
    if name == "mps":
        raise RuntimeError("MPS is not supported because IWVI uses float64 for stable importance weights. Use cpu.")
    return torch.device(name)


def _tensorize(data: NLMEData, device):
    return {k: torch.as_tensor(v, device=device) for k, v in data.as_dict().items()}


def iw_elbo(model, q, theta, batch, K, drep=True, mc_reps=1):
    total = 0.0
    for _ in range(mc_reps):
        eta, log_q = q.rsample_and_logq(batch, K, drep=drep)
        log_p = model.log_joint(batch, eta, theta)
        total = total + (torch.logsumexp(log_p - log_q, dim=0) - math.log(K)).sum()
    return total / mc_reps


@torch.no_grad()
def is_marginal_loglik(model, q, theta, batch, K=4000, chunk=500):
    parts = []
    for start in range(0, K, chunk):
        k = min(chunk, K-start)
        eta, log_q = q.rsample_and_logq(batch, k)
        parts.append(model.log_joint(batch, eta, theta) - log_q)
    log_w = torch.cat(parts, 0)
    ll_i = torch.logsumexp(log_w, 0) - math.log(log_w.shape[0])
    w = torch.softmax(log_w, 0)
    ess = 1.0 / (w**2).sum(0)
    top = w.max(0).values
    return ll_i.sum().item(), ess.cpu().numpy(), top.cpu().numpy()


def _train(model, data: NLMEData, est: IWVI):
    device = _resolve_device(est.device)
    torch.manual_seed(est.seed)
    batch = _tensorize(data, device)
    n_subj, _ = batch["logy"].shape
    encoder_input_dim = None
    if est.posterior == "amortized":
        if "encoder_x" not in batch or "encoder_mask" not in batch:
            raise ValueError(
                "Amortized inference requires encoder features. Pass a DataFrame "
                "through nlmevi()/prepare_data(), or provide encoder_x and "
                "encoder_mask in NLMEData."
            )
        n_events, n_features = batch["encoder_x"].shape[1:]
        # Flatten event x feature values and append one event-presence mask
        # element per padded event row.
        encoder_input_dim = n_events * n_features + n_events
    q = make_posterior(
        est.posterior, est.family, n_subj, model.n_eta, device,
        encoder_input_dim=encoder_input_dim,
    )
    theta = torch.tensor(model.theta_init, device=device, requires_grad=True)

    is_flow = isinstance(q, (FlowPosterior, FlowPosteriorFixedBase))
    if is_flow:
        groups = [
            {"params": [theta], "lr": est.lr},
            {"params": q.base.parameters(), "lr": est.lr},
            {"params": q.flow.parameters(), "lr": est.lr*0.3},
        ]
    else:
        groups = [{"params": [theta], "lr": est.lr}, {"params": q.parameters(), "lr": est.lr}]
    opt = torch.optim.Adam(groups)
    sched = torch.optim.lr_scheduler.StepLR(opt, step_size=2000, gamma=0.7)

    best_loss = float("inf"); best_theta = None; best_q = None
    history = []
    patience = 4; check_every = 250; warmup = 500
    t0 = time.process_time()
    converged = False

    total_steps = est.max_steps if est.adaptive else est.n_steps
    for step in range(1, total_steps+1):
        if is_flow:
            q.strength = min(1.0, (step-1)/warmup)
        opt.zero_grad()
        loss = -iw_elbo(model, q, theta, batch, est.K, est.drep, est.mc_reps) / n_subj
        loss.backward()
        if is_flow:
            torch.nn.utils.clip_grad_norm_([theta] + list(q.base.parameters()), 10.0)
            torch.nn.utils.clip_grad_norm_(q.flow.parameters(), 2.0)
        else:
            torch.nn.utils.clip_grad_norm_([theta] + list(q.parameters()), 10.0)
        opt.step(); sched.step()

        if step % check_every == 0:
            cur = float(loss.detach())
            if cur < best_loss:
                best_loss = cur
                best_theta = theta.detach().clone()
                best_q = copy.deepcopy(q.state_dict())
            om = torch.exp(theta[list(model.omega_indices)]).detach().cpu().numpy()
            history.append((step, om))
            if est.adaptive and step >= est.min_steps and len(history) > patience:
                old = history[-(patience+1)][1]
                rel = np.abs((om-old)/np.clip(np.abs(old), 1e-8, None))
                if np.all(rel < est.tol):
                    converged = True
                    n_run = step
                    break
    else:
        n_run = total_steps
        converged = not est.adaptive

    if best_theta is not None:
        with torch.no_grad(): theta.copy_(best_theta)
        q.load_state_dict(best_q)

    ll, ess, top = is_marginal_loglik(model, q, theta.detach(), batch, est.eval_k)
    cpu = time.process_time() - t0
    theta_np = theta.detach().cpu().numpy()
    return theta_np, q, ll, ess, top, n_run, converged, cpu


def nlmevi(model, data, est: IWVI | None = None, **prepare_kwargs) -> NLMEVIFit:
    """Fit an NLME model with importance-weighted variational inference.

    Parameters
    ----------
    model:
        NLMEModel-like object exposing n_eta, theta_init, parameter_names,
        omega_indices, transform_theta(), and log_joint(batch, eta, theta).
    data:
        pandas.DataFrame in long clinical format, or an NLMEData object.
    est:
        IWVI configuration. K=1 is the ordinary ELBO.
    **prepare_kwargs:
        Passed to prepare_data() when `data` is a DataFrame.
    """
    est = est or IWVI()
    if isinstance(data, pd.DataFrame):
        data = prepare_data(data, **prepare_kwargs)
    if not isinstance(data, NLMEData):
        raise TypeError("data must be a pandas.DataFrame or NLMEData")
    theta, q, ll, ess, top, nrun, conv, cpu = _train(model, data, est)
    estimates = np.asarray(model.transform_theta(theta), dtype=float)
    return NLMEVIFit(model, est, theta, estimates, q, ll, ess, top, nrun, conv, cpu)
