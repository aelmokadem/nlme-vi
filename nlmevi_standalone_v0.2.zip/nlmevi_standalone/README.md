# nlmevi standalone

A deliberately small, reusable Python implementation of importance-weighted
variational inference for nonlinear mixed-effects (NLME) models.

The public API is intentionally similar in spirit to pharmacometric fitting
interfaces:

```python
fit = nlmevi(
    model,
    data,
    est=IWVI(
        posterior="amortized",
        family="flow_fixedbase",
        K=8,
    ),
)
```

This repository is for **usability and experimentation**, not a replacement for
NONMEM, nlmixr2, or a full clinical event engine.

## What it supports

- IW-ELBO with arbitrary `K`; `K=1` is the ordinary ELBO.
- `posterior="free"` or `posterior="amortized"`.
- `family="gaussian"`, `"flow"`, or `"flow_fixedbase"`.
- Doubly-reparameterized gradients (`drep=True`).
- Adaptive convergence monitoring based on omega estimates.
- Best-checkpoint restoration.
- Post-fit importance-sampling marginal log-likelihood, ESS, and top-weight share.
- Long-format clinical data with irregular observation times.
- Subject-specific and repeated dose events.
- Missing observations.
- Baseline covariates retained by the data layer for custom models.
- A minimal model interface so new structural models can be plugged in.

## What it intentionally does NOT support yet

This is not a complete NONMEM/nlmixr2 event system. There is no built-in support
for ADDL/II, steady-state records, infusion-rate switching, reset events,
interoccasion variability, BLQ likelihoods, or arbitrary time-varying
covariate interpolation. Add these only if a project actually needs them.

## Installation

### Option 1: uv

From the repository directory:

```bash
uv venv
source .venv/bin/activate
uv pip install -e .
```

### Option 2: standard pip

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -e .
```

On Windows, activate with:

```powershell
.venv\Scripts\activate
```

## Run the basic example

```bash
python examples/example_basic.py
```

It simulates a repeated-dose oral one-compartment dataset, fits it with
amortized Gaussian IWVI at `K=8`, and prints the fit and parameter estimates.

## Compare VI flavors

```bash
python examples/example_flavors.py
```

This demonstrates:

```python
IWVI(posterior="free",      family="gaussian",       K=1)
IWVI(posterior="amortized", family="gaussian",       K=8)
IWVI(posterior="amortized", family="flow",           K=8)
IWVI(posterior="amortized", family="flow_fixedbase", K=8)
```

`flow_fixedbase` uses a fixed `N(0,I)` flow base and uses the encoder/base
parameters only as the differentiable conditioning input.

## Use your own clinical dataframe

The default column convention is:

```text
ID  TIME  DV  EVID  AMT  CMT
```

For example:

```python
import pandas as pd
from nlmevi import OneCmtOralEvents, IWVI, nlmevi

data = pd.read_csv("my_data.csv")

fit = nlmevi(
    OneCmtOralEvents(),
    data,
    est=IWVI(
        posterior="amortized",
        family="gaussian",
        K=8,
    ),
)

print(fit)
print(fit.summary())
```

Dose rows are identified by `EVID != 0` and `AMT > 0`. Observation rows are
identified by `EVID == 0` and a non-missing `DV`.

Different column names can be passed directly to `nlmevi`:

```python
fit = nlmevi(
    model,
    data,
    est=IWVI(K=8),
    id_col="USUBJID",
    time_col="TAD",
    dv_col="CONC",
    amt_col="DOSE",
)
```

## Choosing the estimator

A few useful configurations:

```python
# Ordinary ELBO, free per-subject Gaussian q
IWVI(posterior="free", family="gaussian", K=1)

# Importance-weighted Gaussian VI
IWVI(posterior="free", family="gaussian", K=8)

# Amortized Gaussian IWVI
IWVI(posterior="amortized", family="gaussian", K=8)

# Conditional normalizing flow with moving Gaussian base
IWVI(posterior="amortized", family="flow", K=8)

# Conditional normalizing flow with fixed N(0,I) base
IWVI(posterior="amortized", family="flow_fixedbase", K=8)
```

For quick exploratory runs, reduce `max_steps` and `eval_k`. For serious fits,
keep float64 and increase them as needed.

## Fit object

```python
fit.params
fit.omega
fit.loglik
fit.ess
fit.top_weight_share
fit.converged
fit.n_steps
fit.cpu_seconds
fit.summary()
```

## Add a new model

The inference engine only needs a small contract. Subclass `NLMEModel` and
provide:

```python
class MyModel(NLMEModel):
    n_eta = 2
    theta_init = [...]
    parameter_names = [...]
    omega_indices = (...)

    def log_joint(self, batch, eta, theta):
        ...
```

`batch` contains the prepared tensors, including:

```text
logy
 t
mask
dose_time
dose_amt
dose_mask
covariates   # if supplied
```

See:

```bash
python examples/example_custom_model.py
```

for a complete toy non-PK model using the same IWVI engine.

## Data/event handling philosophy

The event layer is intentionally simple. `prepare_data()` converts a long
clinical dataframe into padded subject arrays. Structural models decide how to
interpret dose events. The included `OneCmtOralEvents` model analytically sums
contributions from all previous oral doses, so it handles subject-specific and
repeated doses without an ODE solver.

For a future ODE model, the same prepared dose arrays can be used to integrate
between event times and modify compartment states at dose events. That can be
added without changing IWVI itself.

## Tests

Install pytest if needed:

```bash
pip install pytest
pytest -q
```

## Numerical note

The package uses PyTorch float64. Apple MPS does not support float64, so use CPU
on Apple Silicon. CUDA can be requested with `device="cuda"` if available.

## Repository layout

```text
nlmevi_standalone/
├── nlmevi/
│   ├── __init__.py
│   ├── data.py
│   ├── models.py
│   ├── posteriors.py
│   ├── inference.py
│   └── _legacy_core.py
├── examples/
│   ├── example_basic.py
│   ├── example_flavors.py
│   └── example_custom_model.py
├── tests/
│   └── test_smoke.py
├── pyproject.toml
├── requirements.txt
└── README.md
```

`_legacy_core.py` is included only as a reference snapshot of the supplied
project core. The standalone public API does not import it.

## Configurable amortized encoder features

The amortized posterior is not restricted to observation time and DV. By
default, `prepare_data()` builds a padded event sequence from all clinical
rows using:

```python
("TIME", "LOG_DV", "DV_MASK", "EVID", "AMT", "CMT")
```

You can supply any subset plus any numeric dataframe columns:

```python
fit = nlmevi(
    model,
    data,
    est=IWVI(posterior="amortized", family="gaussian", K=8),
    encoder_features=[
        "TIME", "LOG_DV", "DV_MASK", "EVID", "AMT", "CMT",
        "WT", "AGE", "SEX",
    ],
)
```

Dose-only rows are retained in the encoder sequence, so the amortized posterior
can condition on subject-specific dose histories as well as observations.
Built-in names are `TIME`, `DV`, `LOG_DV`, `DV_MASK`, `EVID`, `AMT`, and `CMT`.
Any other requested name is read directly from the dataframe as a numeric
feature. Padding is handled by a separate event mask.

See the complete runnable example:

```bash
python examples/example_amortized_features.py
```
